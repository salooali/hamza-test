import os
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
import csv
import requests
from datetime import date

today = str(date.today())
year = today.split("-")[0]
month = today.split("-")[1]
current_date = today.split("-")[2]


client = WebClient(token="xoxb-513698181365-5920773735633-ZotA7YcaVct4dnX6oe2tJr33")

try:
    response = requests.post(r'https://prod-87.eastus.logic.azure.com:443/workflows/118f68cc5e714bf096c38dab03dde03e/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=0wJWE8UU0Ww5AP5UulnLd7kZ7uiyn9UpwvnTotIJJPI', timeout=30)
    print(response.status_code)
except requests.exceptions.Timeout:
    print('The request timed out')

try:
    # Get the messages from the channel
    response = client.conversations_history(channel="C05S8BAFPJT", limit=1)

    # Extract and print the last message
    if response["messages"]:
        last_message = response["messages"][0]
        #print("Last Message Text:", last_message["text"])
    else:
        print("No messages in the channel.")

except:
    print("Error_1")


a_list = []

try:

    list = last_message["text"].split("\n")

    for item in list:
        b = ''
        b = item.split(",")
        a_list.append(b)


    a_list.remove(a_list[-1])


    with open('query_data.csv', 'w', newline='', encoding="utf-8") as file:
        writer = csv.writer(file)

        for item in a_list:
            writer.writerow(item)

except:
    print ("Error_2")



try:

    os.chdir('C:\\Users\\Ebryx\\Downloads\\Test-code\\SOC-X\\')
    command = r'python C:\Users\Ebryx\Downloads\Test-code\SOC-X\soc-x.py --team soc --work_type monthly_report --client veeone -ry ' + year + ' -rm ' + month + ' --input_file query_data.csv'

    # Run the command using os.system()
    exit_code = os.system(command)

except:
    print ("Error_3")



# response = client.files_upload(
#     channels="GTAAZ284F",
#     initial_comment="Owners VeeOne Here is the first draft of VeeOne monthly report!",
#     file=month + year + "_VEEONE_ThreatReport_v1.0.docx",
# )

# # Check if the file upload was successful
# if response["ok"]:
#     print(f"File uploaded successfully to channel GTAAZ284F")
# else:
#     print(f"File upload failed. Error: {response['error']}")