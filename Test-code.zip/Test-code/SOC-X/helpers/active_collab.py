import json
import requests
from pprint import pprint

from requests.sessions import session
from helpers.utils import config_file_to_dict


class active_collab:


  url = None
  config_file_path = None
  config = None
  session = None
  logger = None
  logged_user_id = None


  def __init__(self, config_file_path, logger):
    self.logger = logger
    self.config_file_path = config_file_path
    self.config = config_file_to_dict(filename=config_file_path)
    self.session = self.create_session(self.config.get('credentials'), self.config.get('url'), self.config.get('endpoints').get('login'))
    self.logger.info('AC init successful...')


  def get_value_containing_str_from_dict_key(self, find, mdict):
    ret = None
    for k, v in mdict.items():
      if find.lower() in k.lower():
        ret = v
        break
    return ret

  
  def create_session(self, creds, url, endpoint):
    session = requests.Session()
    headers = {
      'Host': 'projects.security-ops.net:4848',
      'Accept': 'application/json, text/plain, * / *',
      'Content-Type': 'application/json',
      'Accept-Encoding': 'gzip, deflate',
      'Accept-Language': 'en-US,en;q=0.9'
    }
    credentials = {
      'username': creds.get('email'),
      'password': creds.get('password')
    }
    response = session.request("POST", '{}{}'.format(url, endpoint), headers=headers, data=json.dumps(credentials))
    if response is not None and response.json().get('authenticated_with') == 'UserSession':
      self.logged_user_id = response.json().get('logged_user_id')
      self.logger.info('AC login successful...')
    session.headers.update({'X-Angie-CsrfValidator': self.get_value_containing_str_from_dict_key(
      'csrf',
      response.cookies.get_dict())})
    self.session = session
    # pprint(session.headers)
    # pprint(response.cookies.get_dict())
    return session
  

  def log_time_for_analysis(self, timedelta_to_log, client, date_today):
    # session = self.create_session(self.config.get('credentials'), self.config.get('url'), self.config.get('endpoints').get('login'))
    session = self.session
    headers = {
      'X-Angie-CsrfValidator': session.headers.get('X-Angie-CsrfValidator'),
      'Host': 'projects.security-ops.net:4848',
      'Accept': 'application/json, text/plain, * / *',
      'Content-Type': 'application/json',
      'Accept-Encoding': 'gzip, deflate',
      'Accept-Language': 'en-US,en;q=0.9'
    }
    hours, minutes = self.convert_timedelta(timedelta_to_log)
    pprint(str(date_today))
    self.logger.warn('============================')
    self.logger.warn('Read next question carefully')
    self.logger.warn('============================')
    input('Are you sure that you want to log {0}:{1} ({0} hours and {1} minutes) for your analysis of {2}?...\nP.S: Summary output file is already created, regardless of the option you choose. So don\'t worry...\nPress any key to continue & Ctrl+C to exit...'.format(hours, self.get_prefixed_minutes_str(minutes), client))
    self.logger.warn('============================')

    payload = json.dumps({
      "value": "{}:{}".format(hours, self.get_prefixed_minutes_str(minutes)),
      # "value": "0:01",
      "job_type_id": 1,
      "user_id": self.logged_user_id,
      "record_date": str(date_today),
      # "billable_status": 1,
      "summary": "",
      "task_id": self.config.get('endpoints').get('clients_projects_to_log_analysis').get(client).get('task_id')
    })
    response = session.request("POST",
      '{}{}'.format(self.config.get('url'), self.config.get('endpoints').get('clients_projects_to_log_analysis').get(client).get('project_url')),
      headers=headers,
      data=payload)
    
    if response.status_code == 200: self.logger.info('Successfully logged time...')
    pprint(response)

    session.headers.update({'X-Angie-CsrfValidator': self.get_value_containing_str_from_dict_key(
      'csrf',
      response.cookies.get_dict())})
    self.session = session


  def convert_timedelta(self, duration):
    days, seconds = duration.days, duration.seconds
    hours = days * 24 + seconds // 3600
    minutes = (seconds % 3600) // 60
    return hours, minutes


  def get_prefixed_minutes_str(self, minutes_int):
    ret = minutes_int
    if minutes_int >= 0 and minutes_int < 10:
      ret = '0{}'.format(minutes_int)
    return ret