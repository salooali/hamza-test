# Monthly Report maker


## Requirements
* python3
* The script requires a csv file with following columns:
    - Source : The source of incident
    - Incident : The title of incident
    - Severity : Severity of incident (Informational, Low, Medium, High)
    - Count: Count of the incidents per title
    - Asset Count: Unique assets count
    - Closed: Number of incidents closed
    - Opened: Number of open incidnets
    
a sample file is given at `SOC-X\soc\monthly_report_siem\sample\monthly_report_stats_sample.csv`
* for sentinel based clients:
    - A watchlist needs to be maintained that contains source information for every scheduled query rule
    - A query named `Monthly Report Stats1` has been created for SPTN that correlates the watchlist with the incident title if the incident rule is of scheduled type, in case there is no match from the watchlist then it puts `To Check` in the Source field which can be manually checked from the csv and updated in the watchlist.
    - Run the query from the sentinel and you will get all the stats in under a minute
    - Export the stats in CSV file, skim through for a minutes to see/update any abnormality
    - Feed the CSV to the script.

## How to use
Run this through the `soc-x.py` using the following format:
```
python3 /mnt/d/Office_Content/SOC-X/soc-x.py --team soc --work_type monthly_report --client moonfare -ry 2022 -rm 05 --input_file /mnt/c/Users/junaid.raza/Downloads/moonfare_query_data.csv
```
where:
* `/mnt/d/Office_Content/SOC-X/soc-x.py` is the path to soc-x.py script
* `--team` should soc
* `--work_type` should be monthly_report
* `--client` should be client's name in lower alphabets
* `-ry` is the reporting year
* `-rm` is the reporting month
* `--input_file` is the path to the csv that contains stats from SIEM

## Onboarding a new client
* add the reportee details in the `reportees` folder in a csv file that contains `Name`, `Email` and `Designation`, name it as `clientname.csv`, see already existing files
* add the logo in the png format in the `logos` folder and name it as `client.png`
* update the `reporter.py` if there are any requirements for change of format for a client

## Outcome
* The script produces a .docx file that is a template as per the formatting requirement of the client
* The .docx file is named as `MMYYY_CLIENTNAME_ThreatReport.docx`
* The file contains all the stats/graph and only descriptive sections need to be filled in manually