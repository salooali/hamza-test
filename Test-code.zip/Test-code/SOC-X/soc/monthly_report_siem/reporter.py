import os
from .config import consts
from datetime import date, datetime, timedelta
import docx
from docx import Document
from docx.shared import Cm, Inches, Pt, Mm, RGBColor, Pt
import csv, json
from operator import attrgetter, indexOf, itemgetter
from docx.oxml.ns import qn
from docx.oxml.shared import OxmlElement
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import numpy as np
import matplotlib.pyplot as plt
from datetime import date
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement as OE
from docx.oxml.ns import qn

class monthly_report_parent:
	report_month = ''
	report_year = ''
	client = ''
	input_file = ''
	output_file = ''
	logger = ''
	current_dir = os.path.abspath(os.getcwd())
	ebryx_logo = "{}/soc/monthly_report_siem/logos/ebryx.png".format(current_dir)
	# sptn_logo = "{}/soc/monthly_report_siem/logos/sptn.png".format(current_dir)
	# moonfare_logo = "{}/soc/monthly_report_siem/logos/moonfare.png".format(current_dir)
	# veeone_logo = "{}/soc/monthly_report_siem/logos/moonfare.png".format(current_dir)
	reportees = "{}/soc/monthly_report_siem/reportees".format(current_dir)
	date_format = '%Y-%m'
	default_font_size = 11
	heading_color = RGBColor(0x00, 0x99, 0x99)
	font = 'Calibri'
	color_red = '#FF4B4B'
	color_green = "#A8D08D"
	color_grey = "#C9C9C9"
	color_yellow = "#FFD965"
	color_heading = "#009999"
	color_white = "#FFFFFF"
	color_white_rgb = RGBColor(0xFF, 0xFF, 0xFF)
	color_black_rgb = RGBColor(0x00, 0x00, 0x00)

	header_dict = {}
	header_list = []
	data = {}

	doc = docx.Document()
	section = doc.sections[0]
	section.page_height = Mm(297)
	section.page_width = Mm(210)
	section.left_margin = Cm(2)
	section.right_margin = Cm(2)

	required_columns = [
		'Shift',
		'Analyst',
	]
	non_empty_columns = [
		'Shift',
		'Analyst',
	]

	client_allowed_values = consts.get('client_allowed_values')
	validation_successful = False

	def __init__(self, report_year, report_month, client, input_file, logger):
		logger.info('Initializing the class and variables')
		self.logger = logger
		self.report_month = report_month
		self.report_year = report_year
		self.client = client
		self.input_file = input_file
		self.output_file = '{}{}_{}_ThreatReport_v1.0.docx'.format(report_month, report_year, str(client).upper())

	@staticmethod
	def _validate(self):
		self.logger.info('Validating inputs...')
		if not self.client in self.client_allowed_values:
			raise AttributeError('Client name not allowed, Check client name in the parameters')
		elif datetime.now().year < int(self.report_year):
			raise AttributeError('Year cannot be in future')
		elif datetime.now().month < int(self.report_month):
			raise AttributeError('Month cannot be in future')
		elif int(self.report_year) < 1 or int(self.report_month) < 1:
			raise AttributeError('Month or year value cannot be 0')
		elif not os.path.exists(self.input_file):
			raise AttributeError('Input file path is invalid, the file does not exist')
		elif not self.csv_to_json(self.input_file):
			raise AttributeError('Unable to process the CSV file given')

		# CSV and JSON validator for data
		self.logger.info('Input Validation passed...')
	
	def update_cell_color(self, color, cell, bold, font_color):
		colored = OxmlElement('w:shd')
		colored.set(qn('w:fill'), color)

		# cell_to_update = table.rows[0].cells[0]
		font = cell.paragraphs[0].runs[0].font
		font.bold = bold
		font.color.rgb = font_color

		tc = cell._tc.get_or_add_tcPr()
		tc.append(colored)

	def csv_to_json(self, path):
		#adding the sources
		self.logger.info('Converting the {} CSV to JSON...'.format(path))
		with open(path, encoding='utf-8-sig') as file:
			csvreader = csv.DictReader(file)
			t = set()
			for rows in csvreader:
				id = rows["Source"]
				t.add(id)
			
			# sorting the sources 
			for i in sorted(t):
				self.data[i] = []

		#creating JSON
		with open(path, encoding='utf-8-sig') as file:
			csvreader = csv.DictReader(file)
			for rows in csvreader:
				self.data[rows["Source"]].append(json.loads(json.dumps(rows)))
		self.logger.info('Conversion Complete...')
		return True

	def format_ninja(self, object, font, color, bold, fontsize):
		title_style = object.style
		title_style.font.name = font
		title_style.font.bold = bold
		title_style.font.size = Pt(fontsize)
		title_style.font.color.rgb = color

	def heading_adder(self, doc, heading, level):
		heading = doc.add_heading(heading, level)
		if level == 1:
			self.format_ninja(heading, self.font, self.heading_color, True, 28)
		elif level == 2:
			self.format_ninja(heading, self.font, self.heading_color, True, 20)

	def add_pre_stats(self, doc):
		## Header
		self.logger.info('Adding Cover...')
		header = doc.sections[0].header
		paragraph = header.paragraphs[0]
		paragraph.text = "\t\t"
		logo_run = paragraph.add_run()
		logo_run.add_picture(self.ebryx_logo, width=Inches(2))
		logo_run.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT

		#Report Name
		for i in range(0, 6): doc.add_paragraph().add_run().add_break()

		client_image = doc.add_picture("{}/soc/monthly_report_siem/logos/{}.png".format(self.current_dir, self.client), width=Inches(6.0))

		# if self.client == "sptn":
		# 	client_image = doc.add_picture(self.sptn_logo, width=Inches(6.0))
		# elif self.client == "moonfare":
		# 	client_image = doc.add_picture(self.moonfare_logo, width=Inches(6.0))

		last_paragraph = doc.paragraphs[-1] 
		last_paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER 

		run = doc.add_paragraph().add_run()
		font = run.font
		font.name = self.font
		font.size = Pt(32)
		font.bold = True
		font.color.rgb = self.heading_color
		run.add_text("Threat Report")

		run = doc.add_paragraph().add_run()
		font = run.font
		font.name = self.font
		font.size = Pt(16)
		font.bold = False
		run.add_text(str(date.today().strftime('%B %d, %Y'))) 

		for i in range(0, 3): doc.add_paragraph().add_run().add_break()

		#Endnotes
		run = doc.add_paragraph().add_run()
		font = run.font
		font.name = self.font
		font.size = Pt(16)
		font.bold = True
		run.text = "Monthly Report\t\t\t\t\t\t\t\t\tVersion: 1.0"

		para = doc.add_paragraph()
		para.alignment = WD_PARAGRAPH_ALIGNMENT.JUSTIFY
		run = para.add_run()
		font = run.font
		font.name = self.font
		font.size = Pt(10)
		font.bold = False
		run.add_text("CONFIDENTIAL: The following report is privileged and contains confidential information. Do not distribute, email, fax, or transfer via any electronic mechanism unless it has been approved by the recipient company's security policy. All copies and backups of this document should always be saved on a protected storage. Do not share any of the information contained within this report with anyone unless they are authorized to view the information.")


		## Footer
		footer = doc.sections[0].footer
		# doc.sections[0].different_first_page_header_footer = True
		paragraph = footer.paragraphs[0]
		run = paragraph.add_run()
		font = run.font
		font.name = self.font
		font.size = Pt(12)
		font.bold = False

		run.text = "\tMonthly Threat Report | CONFIDENTIAL | {}".format(str(self.client).upper())

		# if self.client == "sptn":
		# 	run.text = "\tMonthly Threat Report | CONFIDENTIAL | SpartanNash"
		# elif self.client == "moonfare":
		# 	run.text = "\tMonthly Threat Report | CONFIDENTIAL | Moonfare"
		logo_run.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER

		# doc.add_page_break()
		self.logger.info('Cover added...')

	def add_contents(self, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding Table of Content...')
		self.heading_adder(doc, "Table of Content", 1)
		doc.add_paragraph()
		## table of contents here
		self.logger.info('Table of Content Added...')

	def add_report_meta(self, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding Document Details...')
		self.heading_adder(doc, "Document Details", 1)
		# heading = doc.add_heading()

		table = doc.add_table(rows=6, cols=2)
		table.style = 'TableGrid'
		table.columns[0].width = Inches(3.0)
		table.columns[1].width = Inches(5.0)

		table.rows[0].height = Inches(0.25)
		table.rows[0].cells[0].text = "Client"
		self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
		table.rows[0].cells[1].text = self.client.upper()
		self.update_cell_color(self.color_heading, table.rows[0].cells[1], True, self.color_white_rgb)
		table.rows[1].cells[0].text = "Document Title"
		table.rows[1].cells[1].text = "Threat Report"
		table.rows[2].cells[0].text = "Document Type"
		table.rows[2].cells[1].text = "Monthly Report"
		table.rows[3].cells[0].text = "Date"
		table.rows[3].cells[1].text = str(date.today().strftime('%B %d, %Y'))
		table.rows[4].cells[0].text = "Reporting Month"
		table.rows[4].cells[1].text = str(date(1900, int(self.report_month), 1).strftime('%B')) + ", " + str(self.report_year)
		table.rows[5].cells[0].text = "Classification"
		table.rows[5].cells[1].text = "Confidential"

		self.heading_adder(doc, "Report Recipients", 2)

		size = 0
		with open("{}/{}.csv".format(self.reportees, self.client), encoding='utf-8-sig') as file:
			size = len(file.readlines())

		table = doc.add_table(rows=size, cols=3)
		table.style = 'TableGrid'
		table.columns[0].width = Inches(2.0)
		table.columns[1].width = Inches(2.0)
		table.columns[2].width = Inches(4.0)
		table.rows[0].height = Inches(0.25)
		table.rows[0].cells[0].text = "Name"
		self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)

		table.rows[0].cells[1].text = "Designation"
		self.update_cell_color(self.color_heading, table.rows[0].cells[1], True, self.color_white_rgb)

		table.rows[0].cells[2].text = "Email"
		self.update_cell_color(self.color_heading, table.rows[0].cells[2], True, self.color_white_rgb)

		with open("{}/{}.csv".format(self.reportees, self.client), encoding='utf-8-sig') as file:
			csvreader = csv.DictReader(file)
			i = 1
			for rows in csvreader:
				table.rows[i].cells[0].text = rows["Name"]
				table.rows[i].cells[1].text = rows["Designation"]
				table.rows[i].cells[2].text = rows["Email"]

				i+=1

		self.heading_adder(doc, "Change Log", 2)

		table = doc.add_table(rows=2, cols=3)
		table.style = 'TableGrid'
		table.columns[0].width = Inches(2.0)
		table.columns[1].width = Inches(2.0)
		table.columns[2].width = Inches(4.0)
		table.rows[0].height = Inches(0.25)
		table.rows[0].cells[0].text = "Date"
		self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
		table.rows[1].cells[0].text = str(date.today().strftime('%B %d, %Y'))
		table.rows[0].cells[1].text = "Version"
		self.update_cell_color(self.color_heading, table.rows[0].cells[1], True, self.color_white_rgb)
		table.rows[1].cells[1].text = "1.0"
		table.rows[0].cells[2].text = "Comments"
		self.update_cell_color(self.color_heading, table.rows[0].cells[2], True, self.color_white_rgb)
		table.rows[1].cells[2].text = "Created by Automation"

		doc.add_page_break()
		self.logger.info('Document Details added...')

	def executive_summary(self, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding Executive Summary...')
		self.heading_adder(doc, "Executive Summary", 1)

		self.heading_adder(doc, "Azure Sentinel", 2)

		p0 = doc.add_paragraph('Incidents', style='List Bullet')
		title_style = p0.style
		title_style.font.name = self.font
		title_style.font.bold = True
		title_style.font.color.rgb = self.heading_color
		doc.add_paragraph('Incident Items here', style='List Bullet 2')

		doc.add_paragraph().add_run().add_break()
		p1 = doc.add_paragraph('Operations', style='List Bullet')
		title_style = p1.style
		title_style.font.name = self.font
		title_style.font.bold = True
		title_style.font.color.rgb = self.heading_color
		doc.add_paragraph('Operational Items here', style='List Bullet 2')

		doc.add_paragraph().add_run().add_break()
		p2 = doc.add_paragraph('Blockers', style='List Bullet')
		title_style = p2.style
		title_style.font.name = self.font
		title_style.font.bold = True
		title_style.font.color.rgb = self.heading_color
		doc.add_paragraph('Blockers here', style='List Bullet 2')
		
		self.logger.info('Executive Summary Added...')

	def high_pri_findings(self, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding High Priority Findings...')
		self.heading_adder(doc, "High Priority Findings", 1)

		table = doc.add_table(rows=2, cols=1)
		table.style = 'TableGrid'
		table.columns[0].width = Inches(6)

		table.rows[0].height = Inches(0.5)
		table.rows[0].cells[0].text = "High Priority Findings"
		self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
		table.rows[0].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[0].cells[0].paragraphs[0].runs[0].font.size = Pt(14)
		table.rows[0].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)
		table.rows[0].cells[0].paragraphs[0].paragraph_format.space_after = Pt(2)

		p0 = table.rows[1].cells[0].add_paragraph('Finding One', style='List Bullet')
		title_style = p0.style
		title_style.font.name = self.font
		title_style.font.bold = True
		title_style.font.color.rgb = self.heading_color

		doc.add_page_break()
		self.logger.info('High Priority Findings added...')

	def add_source_chart(self, json_data, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding overall incident stats...')
		# sorting the data with severity, count, incident name
		for i in json_data:
			order = ["High", "Medium", "Low", "Informational"]
			json_data[i] = sorted(json_data[i], key=lambda elem: (order.index(elem["Severity"]), 1.0/int(elem["Count"]), elem["Incident"]))

		#logic for adding the stats for all sources
		sources = []
		total = []
		opened = []
		closed = []
		assetcount = []
		for i in json_data:
			sources.append(i)
			openedd = 0
			closedd = 0
			totall = 0
			assetcountt = 0
			for j in json_data[i]:
				for key, value in j.items():
					if key == "Count":
						totall = totall+int(value)
					elif key == "Opened":
						openedd = openedd+int(value)
					elif key == "Closed":
						closedd = closedd+int(value)
					elif key == "Asset Count":
						assetcountt = assetcountt+ int(value)
			total.append(totall)
			opened.append(openedd)
			closed.append(closedd)
			assetcount.append(assetcountt)

		self.heading_adder(doc, "Sentinel Incident Overall Stats", 1)
		table = doc.add_table(rows=3, cols=2)
		table.style = 'TableGrid'
		table.columns[0].width = Inches(3.0)
		table.columns[1].width = Inches(3.0)
		table.rows[0].height = Inches(0.4)
		table.rows[0].cells[0].text = "Total Sentinel Incidents"
		self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
		table.rows[0].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[0].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)
		table.rows[0].cells[1].text = str(sum(total))
		table.rows[0].cells[1].paragraphs[0].runs[0].font.bold = True
		table.rows[0].cells[1].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[0].cells[1].paragraphs[0].paragraph_format.space_before = Pt(6)

		table.rows[1].height = Inches(0.4)
		table.rows[1].cells[0].text = "Closed Sentinel Incidents"
		self.update_cell_color(self.color_green, table.rows[1].cells[0], True, self.color_white_rgb)
		table.rows[1].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[1].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)
		table.rows[2].cells[0].text = str(sum(closed))
		table.rows[2].cells[0].paragraphs[0].runs[0].font.bold = True
		table.rows[2].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[2].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)

		table.rows[2].height = Inches(0.4)
		table.rows[1].cells[1].text = "Open Sentinel Incidents"
		self.update_cell_color(self.color_red, table.rows[1].cells[1], True, self.color_white_rgb)
		table.rows[1].cells[1].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[1].cells[1].paragraphs[0].paragraph_format.space_before = Pt(6)
		table.rows[2].cells[1].text = str(sum(opened))
		table.rows[2].height = Inches(0.4)
		table.rows[2].cells[1].paragraphs[0].runs[0].font.bold = True
		table.rows[2].cells[1].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[2].cells[1].paragraphs[0].paragraph_format.space_before = Pt(6)

		
		width = 0.35
		plt.figure()
		ind = np.arange(len(sources))
		plt.ylabel('Counts')
		plt.title('Sentinel Incident Counts by Sources')
		plt.setp(plt.gca().get_xticklabels(), horizontalalignment='center')
		plt.xticks(ind, range(1, len(sources)+1))
		plt.bar(ind, closed, width, label="Closed Incidents", color=self.color_green)
		plt.bar(ind + width, opened, width, label='Open Incidents', color=self.color_red)
		plt.legend(loc='best')
		plt.savefig('{}/soc/monthly_report_siem/temp.png'.format(self.current_dir))
		table = doc.add_table(rows=1, cols=1)
		table.columns[0].width = Inches(6.0)
		table.style = 'TableGrid'
		p = table.rows[0].cells[0].add_paragraph().add_run().add_picture('{}/soc/monthly_report_siem/temp.png'.format(self.current_dir))
		table.rows[0].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		table.rows[0].cells[0].paragraphs[0].paragraph_format.space_before = Pt(0)
		table.rows[0].cells[0].paragraphs[0].paragraph_format.space_after = Pt(4)
		doc.add_paragraph()

		table = doc.add_table(rows=1, cols=6)
		table.columns[0].width = Inches(0.08)
		table.columns[1].width = Inches(4.33)
		table.columns[2].width = Inches(0.1667)
		table.columns[3].width = Inches(0.1667)
		table.columns[4].width = Inches(0.1667)
		table.columns[5].width = Inches(0.1667)
		table.style = 'TableGrid'

		headings = table.rows[0].cells
		t = 0
		headings[0].text = "#"
		headings[1].text = "Scope"
		headings[2].text = "Incident Count"
		headings[3].text = "Closed Incidents"
		headings[4].text = "Open Incidents"
		headings[5].text = "Assets Count"
		for heading in headings:
			# print(heading)
			self.update_cell_color(self.color_heading, heading, True, self.color_white_rgb)
			heading.paragraphs[0].runs[0].font.bold = True
		
		for i in range(0, len(sources)):
			row = table.add_row().cells
			row[0].text = str(i+1)
			row[1].text = sources[i]
			row[1].paragraphs[0].runs[0].font.bold = True
			row[2].text = str(total[i])
			row[2].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			row[3].text = str(closed[i])
			row[3].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			row[4].text = str(opened[i])
			row[4].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			row[5].text = str(assetcount[i])
			row[5].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
		
		doc.add_page_break()
		self.logger.info('Overall incident stats added...')

		#logic for adding stats by source
		self.logger.info('Adding stats by Log Sources...')
		self.heading_adder(doc, "Sentinel Incident Stats by Log Source", 1)
		for i in json_data:
			self.logger.info('Adding stats for Log Sources: {}'.format(i))
			self.heading_adder(doc, i, 2)

			#-> bar chart
			width = 0.35
			plt.figure()
			ind = np.arange(len(json_data[i]))
			plt.ylabel('Counts')
			plt.title('Counts by Total Sentinel Incidents')
			plt.setp(plt.gca().get_xticklabels(), horizontalalignment='center')
			plt.xticks(ind, range(1, len(json_data[i])+1))
			high_inc = 0
			medium_inc = 0
			low_inc = 0
			info_inc = 0

			for sev in ("High", "Medium", "Low", "Informational"):
				incidents = []
				opened = []
				closed = []
				counts = []
				colorr = ""
				if sev == "High":
					colorr = self.color_red
				elif sev == "Medium":
					colorr = self.color_yellow
				elif sev == "Low":
					colorr = self.color_green
				elif sev == "Informational":
					colorr = self.color_grey

				for j in json_data[i]:
					incident_temp = ""
					count_temp = ""
					opened_temp = ""
					closed_temp = ""
					seve_temp = ""
					for key, value in j.items():
						if key == "Incident":
							incident_temp = value
						elif key == "Count":
							count_temp = value
						elif key == "Opened":
							opened_temp = value
						elif key == "Closed":
							closed_temp = value
						elif key == "Severity":
							seve_temp = value
					if seve_temp == sev:
						incidents.append(incident_temp)
						opened.append(opened_temp)
						closed.append(closed_temp)
						counts.append(int(count_temp))
						if sev == "High":
							high_inc += int(count_temp)
						elif sev == "Medium":
							medium_inc += int(count_temp)
						elif sev == "Low":
							low_inc += int(count_temp)
						elif sev == "Informational":
							info_inc += int(count_temp)
					else:
						counts.append(0)

				plt.bar(ind, counts, width, label=sev, color=colorr)
				plt.legend(loc='best')
				# plt.bar(ind + width, opened, width, label='Open', color="red")
				# plt.xticks(fontsize=7, rotation=5, wrap=True)
				# print(counts, sum(counts))
				plt.savefig('{}/soc/monthly_report_siem/temp.png'.format(self.current_dir))
			# plt.show()


			#-> bar chart end

			#-> start 
			table = doc.add_table(rows=1, cols=2)
			table.style = 'TableGrid'
			table.columns[0].width = Inches(3.0)
			table.columns[1].width = Inches(3.0)
			table.rows[0].cells[0].text = "Total Sentinel Incidents"
			table.rows[0].cells[1].text = str(sum([high_inc, medium_inc, low_inc, info_inc]))
			self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
			table.rows[0].height = Inches(0.4)
			table.rows[0].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[0].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)

			table.rows[0].cells[1].paragraphs[0].runs[0].font.bold = True
			table.rows[0].cells[1].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[0].cells[1].paragraphs[0].paragraph_format.space_before = Pt(6)

			table = doc.add_table(rows=2, cols=4)
			table.style = 'TableGrid'
			table.columns[0].width = Inches(1.5)
			table.columns[1].width = Inches(1.5)
			table.columns[2].width = Inches(1.5)
			table.columns[3].width = Inches(1.5)
			table.rows[0].height = Inches(0.4)
			table.rows[1].height = Inches(0.4)
			table.rows[0].cells[0].text = "High"
			self.update_cell_color(self.color_red, table.rows[0].cells[0], True, self.color_white_rgb)
			table.rows[0].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[0].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)

			table.rows[0].cells[1].text = "Medium"
			self.update_cell_color(self.color_yellow, table.rows[0].cells[1], True, self.color_white_rgb)
			table.rows[0].cells[1].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[0].cells[1].paragraphs[0].paragraph_format.space_before = Pt(6)

			table.rows[0].cells[2].text = "Low"
			self.update_cell_color(self.color_green, table.rows[0].cells[2], True, self.color_white_rgb)
			table.rows[0].cells[2].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[0].cells[2].paragraphs[0].paragraph_format.space_before = Pt(6)

			table.rows[0].cells[3].text = "Infomational"
			self.update_cell_color(self.color_grey, table.rows[0].cells[3], True, self.color_white_rgb)
			table.rows[0].cells[3].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[0].cells[3].paragraphs[0].paragraph_format.space_before = Pt(6)

			table.rows[1].cells[0].text = str(high_inc)
			table.rows[1].cells[0].paragraphs[0].runs[0].font.bold = True
			table.rows[1].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[1].cells[1].text = str(medium_inc)
			table.rows[1].cells[1].paragraphs[0].runs[0].font.bold = True
			table.rows[1].cells[1].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[1].cells[2].text = str(low_inc)
			table.rows[1].cells[2].paragraphs[0].runs[0].font.bold = True
			table.rows[1].cells[2].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[1].cells[3].text = str(info_inc)
			table.rows[1].cells[3].paragraphs[0].runs[0].font.bold = True
			table.rows[1].cells[3].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			# doc.add_picture('/mnt/d/Office_Content/SOC-X - Copy/soc/monthly_report_siem/temp.png') 

			table = doc.add_table(rows=1, cols=1)
			table.columns[0].width = Inches(6.0)
			table.style = 'TableGrid'
			p = table.rows[0].cells[0].add_paragraph().add_run().add_picture('{}/soc/monthly_report_siem/temp.png'.format(self.current_dir))
			table.rows[0].cells[0].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
			table.rows[0].cells[0].paragraphs[0].paragraph_format.space_before = Pt(0)
			table.rows[0].cells[0].paragraphs[0].paragraph_format.space_after = Pt(4)
			doc.add_paragraph()
			
			#-> end

			table = doc.add_table(rows=1, cols=len(json_data[i][0]))
			table.columns[0].width = Inches(0.08)
			table.columns[1].width = Inches(4.33)
			table.columns[2].width = Inches(0.1667)
			table.columns[3].width = Inches(0.1667)
			table.columns[4].width = Inches(0.1667)
			table.columns[5].width = Inches(0.1667)
			table.columns[6].width = Inches(0.1667)
			table.style = 'TableGrid'
			headings = table.rows[0].cells

			t = 0
			headings[0].text = "#"
			self.update_cell_color(self.color_heading, headings[0], True, self.color_white_rgb)
			for key, value in json_data[i][0].items():
				if key != "Source":
					headings[t].text = key
					self.update_cell_color(self.color_heading, headings[t], True, self.color_white_rgb)
				t+=1

			high = OxmlElement('w:shd')
			high.set(qn('w:fill'), self.color_red)
			medium = OxmlElement('w:shd')
			medium.set(qn('w:fill'), self.color_yellow)
			low = OxmlElement('w:shd')
			low.set(qn('w:fill'), self.color_green)
			informational = OxmlElement('w:shd')
			informational.set(qn('w:fill'), self.color_grey)
			count = 1
			for j in json_data[i]:
				# print(j)
				t = 0
				row = table.add_row().cells
				row[0].text = str(count)
				for key, value in j.items():
					# print(key, value)
					if key != "Source":
						row[t].text = value
						row[t].paragraphs[0].runs[0].font.size = Pt(self.default_font_size)
						if key != "Incident":
							row[t].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
						if key == "Severity":
							if value == "High":
								self.update_cell_color(self.color_red, row[t], False, self.color_black_rgb)
								row[t].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
							elif value == "Medium":
								# print("in medium")
								self.update_cell_color(self.color_yellow, row[t], False, self.color_black_rgb)
								row[t].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
							elif value == "Low":
								# print("in low")
								self.update_cell_color(self.color_green, row[t], False, self.color_black_rgb)
								row[t].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
							elif value == "Informational":
								self.update_cell_color(self.color_grey, row[t], False, self.color_black_rgb)
								row[t].paragraphs[0].alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
					# print(t, row[t].text)
					t+=1
				count+=1
			
			doc.add_page_break()
		self.logger.info('Inicdents by log sources added...')
		
	def threat_score(self, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding threat score...')
		self.heading_adder(doc, "Threat Score", 1)
		
		table = doc.add_table(rows=4, cols=2)
		table.style = 'TableGrid'
		table.columns[0].width = Inches(3)
		table.columns[1].width = Inches(3)

		table.rows[0].cells[0].text = "Security State"
		table.rows[0].height = Inches(0.5)
		self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
		table.rows[0].cells[0].paragraphs[0].runs[0].font.size = Pt(14)
		table.rows[0].cells[0].paragraphs[0].paragraph_format.space_before = Pt(10)
		table.rows[1].cells[0].text = "Threat Level"
		table.rows[1].height = Inches(0.4)
		self.update_cell_color(self.color_heading, table.rows[1].cells[0], True, self.color_white_rgb)
		table.rows[1].cells[0].paragraphs[0].runs[0].font.size = Pt(14)
		table.rows[1].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)
		table.rows[2].cells[0].text = "Threat Score"
		table.rows[2].height = Inches(0.4)
		self.update_cell_color(self.color_heading, table.rows[2].cells[0], True, self.color_white_rgb)
		table.rows[2].cells[0].paragraphs[0].runs[0].font.size = Pt(14)
		table.rows[2].cells[0].paragraphs[0].paragraph_format.space_before = Pt(6)
		table.rows[3].cells[0].text = "Reasoning for Threat Score"
		table.rows[3].height = Inches(1)
		self.update_cell_color(self.color_heading, table.rows[3].cells[0], True, self.color_white_rgb)
		table.rows[3].cells[0].paragraphs[0].runs[0].font.size = Pt(14)
		table.rows[3].cells[0].paragraphs[0].paragraph_format.space_before = Pt(20)

		table.rows[2].cells[1].text = "X"

		self.logger.info('Threat Score added...')

	def recommendations(self, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding Recommendations...')
		if self.client == "moonfare":
			self.heading_adder(doc, "Top Action Items", 1)
		else:
			self.heading_adder(doc, "Recommendations", 1)

		p0 = doc.add_paragraph('Based upon the alerts raised and the needs identified in the past month, following table consists of several recommendations and improvements:')
		
		table = doc.add_table(rows=2, cols=4)
		table.style = 'TableGrid'
		table.columns[0].width = Inches(1.0)
		table.columns[1].width = Inches(1.75)
		table.columns[2].width = Inches(1.75)
		table.columns[3].width = Inches(1.75)
		
		table.rows[0].height = Inches(0.3)
		table.rows[0].cells[0].text = "#"
		self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
		table.rows[0].cells[1].text = "Scope"
		self.update_cell_color(self.color_heading, table.rows[0].cells[1], True, self.color_white_rgb)
		table.rows[0].cells[2].text = "Priority"
		self.update_cell_color(self.color_heading, table.rows[0].cells[2], True, self.color_white_rgb)
		table.rows[0].cells[3].text = "Recommendation"
		self.update_cell_color(self.color_heading, table.rows[0].cells[3], True, self.color_white_rgb)

		table.rows[1].cells[0].text = "1"

		self.logger.info('Recommendations added...')

	def ch_n_bl(self, doc):
		doc.add_section(WD_SECTION.NEW_PAGE)
		self.logger.info('Adding Challenges and Blockers...')
		if self.client == "moonfare":
			self.heading_adder(doc, "Challenges", 1)
		else:
			self.heading_adder(doc, "Challenges and Blockers", 1)

		p0 = doc.add_paragraph('Following are the main challenges and blockers faced during the past month:')
		
		p0 = doc.add_paragraph('', style='List Bullet')

		doc.add_page_break()
		self.logger.info('Challenges and Blockers added...')

	def appendix(self, doc):
		if self.client == "sptn":			
			doc.add_section(WD_SECTION.NEW_PAGE)
			self.logger.info('Adding Appendix...')
			self.heading_adder(doc, "Appendix", 1)

			self.heading_adder(doc, "Appendix - Cherwell Security Incidents", 2)

			table = doc.add_table(rows=2, cols=3)
			table.style = 'TableGrid'
			table.columns[0].width = Inches(1.0)
			table.columns[1].width = Inches(3.5)
			table.columns[2].width = Inches(3.5)

			table.rows[0].cells[0].text = "#"
			self.update_cell_color(self.color_heading, table.rows[0].cells[0], True, self.color_white_rgb)
			table.rows[0].cells[1].text = "Ticket Title"
			self.update_cell_color(self.color_heading, table.rows[0].cells[1], True, self.color_white_rgb)
			table.rows[0].cells[2].text = "Ticket ID"
			self.update_cell_color(self.color_heading, table.rows[0].cells[2], True, self.color_white_rgb)

			table.rows[1].cells[0].text = "1"

			doc.add_page_break()
		self.logger.info('Appendix Added...')

	def add_list_of_table(self, run):
		fldChar = OE('w:fldChar')
		fldChar.set(qn('w:fldCharType'), 'begin')
		fldChar.set(qn('w:dirty'), 'true')
		instrText = OE('w:instrText')
		instrText.set(qn('xml:space'), 'preserve')
		instrText.text = "TOC\\o \"1-3\" \\h \\z \\u \"Table\""  #"Table" of list of table and "Figure" for list of figure
		fldChar2 = OE('w:fldChar')
		fldChar2.set(qn('w:fldCharType'), 'separate')
		fldChar3 = OE('w:t')
		fldChar3.text = "Right-click to update field."
		fldChar2.append(fldChar3)
		
		fldChar4 = OE('w:fldChar')
		fldChar4.set(qn('w:fldCharType'), 'end')
		
		print(fldChar, instrText, fldChar2, fldChar4)
		run._r.append(fldChar)
		run._r.append(instrText)
		run._r.append(fldChar2)
		run._r.append(fldChar4)
	
	def update_table_of_content(self, doc):
		self.logger.info('Updating Table of Content...')
		
		# doc.paragraphs[16].insert_paragraph_before(text="askdasdsjkfjsf")
		# print(doc.paragraphs[16]._p.xml)
		self.add_list_of_table(doc.paragraphs[16].add_run())
		self.logger.info('Table of Content Updated...')	

	def doc_builder(self):
		self.add_pre_stats(self.doc)
		self.add_contents(self.doc)
		self.add_report_meta(self.doc)
		self.executive_summary(self.doc)
		self.high_pri_findings(self.doc)
		self.add_source_chart(self.data, self.doc)
		self.threat_score(self.doc)
		self.recommendations(self.doc)
		self.ch_n_bl(self.doc)
		self.appendix(self.doc)
		# self.update_table_of_content(self.doc)

		self.logger.info('Build Complete...')
		self.logger.info('Saving the Doc...')
		self.doc.save('{}/{}'.format(os.path.abspath(os.getcwd()), self.output_file))
		self.logger.info('Doc Saved at: {}/{}'.format(os.path.abspath(os.getcwd()), self.output_file))
		# self.update_toc('{}/{}'.format(os.path.abspath(os.getcwd()), self.output_file))
	
	def create_report(self):
		self._validate(self)
		self.doc_builder()