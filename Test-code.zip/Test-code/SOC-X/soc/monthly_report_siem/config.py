consts = {
    'client_allowed_values': [
        'careem',
        'moonfare',
        'smiota',
        'veeone',
        'fmfb',
        'bipl',
        'sptn',
        'ebryx',
        'fe'
    ]
}