# Informer

This README provides a detailed understanding of Optimus Prime's summary automation colleague "Informer"  

## Structure  

```markdown
Informer  
├── config.yml
├── informer.py
├── README.md  
└── requirements.txt
```

The automation script is well-commented but not modular. Modular approach is a work in-progress.

## Workflow

The related workflow for Informer is `informer.yml`. To understand the working of this Github Action/Workflow, refer to the following below:

`Triggers:` The workflow can trigger both mnually and based on CRON jobs.
`Environment:` For execution, the workflow needs python3.x, and following repository secrets.

```markdown
SUMMARIES_SERVICE_ACCOUNT_PROJECT_ID
SUMMARIES_SERVICE_ACCOUNT_PRIVATE_KEY_ID
SUMMARIES_SERVICE_ACCOUNT_PRIVATE_KEY
SUMMARIES_SERVICE_ACCOUNT_CLIENT_EMAIL
SUMMARIES_SERVICE_ACCOUNT_CLIENT_ID
SUMMARIES_SERVICE_ACCOUNT_CLIENT_X509_CERT_URL
EMAIL_PASS
```

The automation also requires timezone to be set to "Asia/Karachi" otherwise summaries/reports will not be delivered on the required time.

## Configuration

The configuration file of Informer only expects organizational configuration and any carelessly written configuration will break the execution. Following are the details of an organization's configuration.

**`organization_name:`**
    **`logo:`** "URL of the logo that will be placed on top right of the report"  
    **`name:`** "Name of the client organization"  
    **`code:`** "Codename of the client organization. Reports will be generated using this name."  
    **`spreadsheet:`**  
        **`id:`** "ID of the Google spreadsheet."  
        **`worksheet_id:`** Google worksheet ID in integers.  
    **`from_email:`** "Email address to send the reports from."  
    **`to_email:`** "Email address to send the reports to."  
    **`pass:`** "Variable name of the repository secret having password of the email from which email will be sent."  
    **`submission_time:`** "Time in PKT at which the report will be sent, for example 00:00"  
    **`day_factor:`** "This can be 1, 0 or -1 based on the execution time and the geolocation of customer organization. If report is to be sent at 00:30 midnight, the data points will be collected from previous day according to PKT so day_factor would be -1."  
    **`visualizations:`**  
        **`analyst_time:`** "This can be True or False. Default is False. Make it True in case you want to show the visualization on the report that tells how much analyst time is consumed on what kind of resources."  

## Organization On-boarding

If you want to on-board an organization for automated reporting, just follow these 3 steps:

1. Grant `Viewer` access of the organization's analysis sheet to _autobot@gsheets-333702.iam.gserviceaccount.com_
2. Add the configuration for the organization in `config.yml`.
3. Add the CRON job in the workflow `informer.yml`.
