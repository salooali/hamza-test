import gspread
import yaml
import os
import smtplib
# import pdfkit

#from xhtml2pdf import pisa
from oauth2client.service_account import ServiceAccountCredentials
from datetime import date, datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# Service account JSON
SERVICE_ACCOUNT_JSON = { "type": "service_account", "project_id": os.environ['SUMMARIES_SERVICE_ACCOUNT_PROJECT_ID'], "private_key_id": os.environ['SUMMARIES_SERVICE_ACCOUNT_PRIVATE_KEY_ID'], "private_key": os.environ['SUMMARIES_SERVICE_ACCOUNT_PRIVATE_KEY'], "client_email": os.environ['SUMMARIES_SERVICE_ACCOUNT_CLIENT_EMAIL'], "client_id": os.environ['SUMMARIES_SERVICE_ACCOUNT_CLIENT_ID'], "auth_uri": "https://accounts.google.com/o/oauth2/auth", "token_uri": "https://oauth2.googleapis.com/token", "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs", "client_x509_cert_url": os.environ['SUMMARIES_SERVICE_ACCOUNT_CLIENT_X509_CERT_URL'] }

# Get today's date and time
DATE = str(date.today())
TODAY = DATE.split("-")[2]
THIS_MONTH = DATE.split("-")[1]
TIME = datetime.now().strftime("%H:%M")
EXECUTION_HOUR = TIME.split(":")[0]
EXECUTION_MINUTE = TIME.split(":")[1]

# Load the config
CONFIG_FILE_PATH = os.path.dirname(os.path.abspath(__file__)) + "/config.yml"
CONFIG = (
	yaml.load(open(CONFIG_FILE_PATH), Loader=yaml.FullLoader)
	if os.path.isfile(CONFIG_FILE_PATH)
	else {}
)

# Iterate over all organizations
for Organization in CONFIG:

	Summary_Hour = CONFIG[Organization]["submission_time"].split(":")[0]
	Summary_Minute = CONFIG[Organization]["submission_time"].split(":")[1]

	if int(EXECUTION_HOUR) == int(Summary_Hour) and int(EXECUTION_MINUTE) >= int(Summary_Minute) and int(EXECUTION_MINUTE) < int(Summary_Minute)+30:
		
		print("Posting summary for: "+Organization)

		# Declarations
		Column_Header = [
			"Shift",
			"Analyst",
			"Analysis Date",
			"Datasource",
			"Alert ID(s)",
			"Alert Title",
			"Alert Details",
			"Time of first event",
			"Time of last event",
			"Events Count",
			"Alerts Count",
			"Alert Priority",
			"Alert Status",
			"Analysis Status",
			"Time Spent",
			"Ticket ID",
			"Action Items"
		]

		Summary = {
			"Morning" : """""",
			"Evening" : """""",
			"Night" : """"""
		}

		Stats = {
			"Alert_Priority" : {
				"Critical" : 0,
				"High" : 0,
				"Medium" : 0,
				"Low" : 0,
				"Informational" : 0
			},
			"Alert_Status" : {
				"Done" : 0,
				"NoActions" : 0,
				"In-Progress" : 0,
				"Pending" : 0
			},
			"Time_Spent" : {
				"TP" : 0,
				"TN" : 0,
				"FP" : 0,
				"FN" : 0,
				"Undecided" : 0,
				"NoActionable" : 0,
				"Informational" : 0
			},
			"Ratio" : {
				"TP" : 0,
				"TN" : 0,
				"FP" : 0,
				"FN" : 0,
				"Undecided" : 0,
				"NoActionable" : 0,
				"Informational" : 0
			},
			"Daily_Ratio" : {
				"TP" : 0,
				"TN" : 0,
				"FP" : 0,
				"FN" : 0,
				"Undecided" : 0,
				"NoActionable" : 0,
				"Informational" : 0
			},
			"Shift" : {
				"Morning" : 0,
				"Evening" : 0,
				"Night" : 0
			},
			"Data_Sources" : {}
		}

		# Document ID
		SPREADSHEET_ID = CONFIG[Organization]["spreadsheet"]["id"]

		# Authenticate and Authorize through Oauth
		SCOPE_OF_SHEET = ['https://spreadsheets.google.com/feeds']
		CREDENTIALS = ServiceAccountCredentials.from_json_keyfile_dict(SERVICE_ACCOUNT_JSON, SCOPE_OF_SHEET)
		CLIENT = gspread.authorize(CREDENTIALS)
		SPREADSHEET = CLIENT.open_by_key(SPREADSHEET_ID)

		# Download the spreadsheet
		ANALYSIS_SUMMARY = SPREADSHEET.get_worksheet_by_id(CONFIG[Organization]["spreadsheet"]["worksheet_id"])
		ANALYSIS = ANALYSIS_SUMMARY.get_all_records(empty2zero=False, head=1, default_blank="", allow_underscores_in_numeric_literals=True, numericise_ignore=['all'], value_render_option="FORMATTED_VALUE")

		# Iterate over each analysis row from the bottom of the sheet
		Summary_Body = """"""
		for Row in ANALYSIS:
			
			if str(Row[Column_Header[2]]) != "" and str(Row[Column_Header[2]]).split("-")[2] == str(int(TODAY)+CONFIG[Organization]["day_factor"]):
				Summary_Body += """
				<tr><td class='key'><div id='alarm'>""" + str(Row[Column_Header[4]]).replace("\r\n","</br>").replace("\n","</br>") + """</div></td>
				<td class='value'>
				<strong>Shift: </strong>""" + str(Row[Column_Header[0]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Date: </strong>""" + str(Row[Column_Header[2]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Datasource: </strong>""" + str(Row[Column_Header[3]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Alert Title: </strong>""" + str(Row[Column_Header[5]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Alert Details: </strong>""" + str(Row[Column_Header[6]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>First Event: </strong>""" + str(Row[Column_Header[7]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Last Event: </strong>""" + str(Row[Column_Header[8]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Number of Events: </strong>""" + str(Row[Column_Header[9]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Number of Alerts: </strong>""" + str(Row[Column_Header[10]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Alert Priority: </strong>""" + str(Row[Column_Header[11]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Alert Status: </strong>""" + str(Row[Column_Header[12]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Analysis Status: </strong>""" + str(Row[Column_Header[13]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Ticket ID: </strong>""" + str(Row[Column_Header[15]]).replace("\r\n","</br>").replace("\n","</br>") + """</br>
				<strong>Action Items: </strong>""" + str(Row[Column_Header[16]]).replace("\r\n","</br>").replace("\n","</br>") + """</td>
				</tr>
				"""

				# Add summary per shift
				if str(Row[Column_Header[0]]) == "Morning":
					Stats["Shift"]["Morning"] += 1
					Summary["Morning"] += Summary_Body
				if str(Row[Column_Header[0]]) == "Evening":
					Stats["Shift"]["Evening"] += 1
					Summary["Evening"] += Summary_Body
				if str(Row[Column_Header[0]]) == "Night":
					Stats["Shift"]["Night"] += 1
					Summary["Night"] += Summary_Body

				# Calculate daily stats for Analysis Status
				if str(Row[Column_Header[13]]) == "TP":
					Stats["Daily_Ratio"]["TP"] += 1
				elif str(Row[Column_Header[13]]) == "TN":
					Stats["Daily_Ratio"]["TN"] += 1
				elif str(Row[Column_Header[13]]) == "FP":
					Stats["Daily_Ratio"]["FP"] += 1
				elif str(Row[Column_Header[13]]) == "FN":
					Stats["Daily_Ratio"]["FN"] += 1
				elif str(Row[Column_Header[13]]) == "Undecided":
					Stats["Daily_Ratio"]["Undecided"] += 1
				elif str(Row[Column_Header[13]]) == "TP without Actionable":
					Stats["Daily_Ratio"]["NoActionable"] += 1
				elif str(Row[Column_Header[13]]) == "Informational":
					Stats["Daily_Ratio"]["Informational"] += 1

			# Calculate stats for Analysis Status
			if str(Row[Column_Header[13]]) == "TP":
				Stats["Ratio"]["TP"] += 1
			elif str(Row[Column_Header[13]]) == "TN":
				Stats["Ratio"]["TN"] += 1
			elif str(Row[Column_Header[13]]) == "FP":
				Stats["Ratio"]["FP"] += 1
			elif str(Row[Column_Header[13]]) == "FN":
				Stats["Ratio"]["FN"] += 1
			elif str(Row[Column_Header[13]]) == "Undecided":
				Stats["Ratio"]["Undecided"] += 1
			elif str(Row[Column_Header[13]]) == "TP without Actionable":
				Stats["Ratio"]["NoActionable"] += 1
			elif str(Row[Column_Header[13]]) == "Informational":
				Stats["Ratio"]["Informational"] += 1
			
			# Calculate stats for Alert Priority
			if str(Row[Column_Header[11]]) == "Critical":
				Stats["Alert_Priority"]["Critical"] += 1
			if str(Row[Column_Header[11]]) == "High":
				Stats["Alert_Priority"]["High"] += 1
			if str(Row[Column_Header[11]]) == "Medium":
				Stats["Alert_Priority"]["Medium"] += 1
			if str(Row[Column_Header[11]]) == "Low":
				Stats["Alert_Priority"]["Low"] += 1
			if str(Row[Column_Header[11]]) == "Informational":
				Stats["Alert_Priority"]["Informational"] += 1
			
			# Calculate stats for Alert Status
			if str(Row[Column_Header[12]]) == "Done":
				Stats["Alert_Status"]["Done"] += 1
			if str(Row[Column_Header[12]]) == "Done without actions performed":
				Stats["Alert_Status"]["NoActions"] += 1
			if str(Row[Column_Header[12]]) == "In-Progress":
				Stats["Alert_Status"]["In-Progress"] += 1
			if str(Row[Column_Header[12]]) == "Pending":
				Stats["Alert_Status"]["Pending"] += 1
			
			# Calculate time spent on alerts
			if Row[Column_Header[14]] != "":
				Time_Spent_List = Row[Column_Header[14]].split(":")
				Time_Spent_On_Alert = ((int(Time_Spent_List[0])*60) + (int(Time_Spent_List[1])) + (int(Time_Spent_List[2])/60)) / 60
				if str(Row[Column_Header[13]]) == "TP":
					Stats["Time_Spent"]["TP"] += Time_Spent_On_Alert
				elif str(Row[Column_Header[13]]) == "TN":
					Stats["Time_Spent"]["TN"] += Time_Spent_On_Alert
				elif str(Row[Column_Header[13]]) == "FP":
					Stats["Time_Spent"]["FP"] += Time_Spent_On_Alert
				elif str(Row[Column_Header[13]]) == "FN":
					Stats["Time_Spent"]["FN"] += Time_Spent_On_Alert
				elif str(Row[Column_Header[13]]) == "Undecided":
					Stats["Time_Spent"]["Undecided"] += Time_Spent_On_Alert
				elif str(Row[Column_Header[13]]) == "TP without Actionable":
					Stats["Time_Spent"]["NoActionable"] += Time_Spent_On_Alert
				elif str(Row[Column_Header[13]]) == "Informational":
					Stats["Time_Spent"]["Informational"] += Time_Spent_On_Alert
			
			# Calculate data source matrics
			if Row[Column_Header[3]] != "" and CONFIG[Organization]["code"] in Row[Column_Header[3]]:
				if str(Row[Column_Header[3]]) not in Stats["Data_Sources"]:
					Stats["Data_Sources"][Row[Column_Header[3]]] = {
						"Total" : 0,
						"FP" : 0,
						"Time_Spent" : 0
					}
				if str(Row[Column_Header[13]]) == "FP":
					Stats["Data_Sources"][Row[Column_Header[3]]]["FP"] += 1
				Time_Spent_On_Source_Alert = Row[Column_Header[14]].split(":")
				Time_Spent_On_Source = ((int(Time_Spent_On_Source_Alert[0])*60) + (int(Time_Spent_On_Source_Alert[1])) + (int(Time_Spent_On_Source_Alert[2])/60)) / 60
				Stats["Data_Sources"][Row[Column_Header[3]]]["Time_Spent"] += Time_Spent_On_Source
				Stats["Data_Sources"][Row[Column_Header[3]]]["Total"] += 1
				
		Data_Source_Table = [["Data Source", "Total", "FPs", "Time Spent"]]
		for DataSource in Stats["Data_Sources"]:
			Log_Source = DataSource.replace(CONFIG[Organization]["code"] + " - ", "")
			Data_Source_Table.append([Log_Source, Stats["Data_Sources"][DataSource]["Total"], Stats["Data_Sources"][DataSource]["FP"], Stats["Data_Sources"][DataSource]["Time_Spent"]])

		##########################
		## Begin compiling HTML ##
		##########################

		# Add HTML and HEAD
		HTML = """<html>"""
		HEAD = """
		<head>
			<title>SOC Analysis Summary</title>
			<style type="text/css">
				body { background: #FFF; font-family: 'Roboto Condensed', Helvetica, Arial;}
				h1 { color: #222; margin-bottom: 0px;}
				td {min-width: 60px; padding: 5px; vertical-align: top;}
				.logo { background: #333; width: 50px; padding: 5px; min-width: 0px; }
				.title { background: #333; font-size: 14px; font-family-weight: bold; color: #FFF; }
				.top {background: #333; font-size: 32px; font-weight: bold;
					color: #FFF; ext-align: left; padding: 0px 0px 0px 10px; vertical-align: middle; }
				th {background: #333; font-size: 20px; font-weight: 700; color: #FFF;
					text-align: left; padding: 5px; }
				.section {background: #333; font-size: 14px; font-weight: bold;
					color: #FFF; text-align: left; }
				.toptable { vertical-align: top; padding: 0px; }
				a {size: 10px; color: #00bcd4; text-decoration: none; }
				strong {font-weight: 700;}
				.aAnker {color: #FFF !important;}
				.key {background: #666666; color: #FFF; min-width: 100px; width: 100px; }
				.value {background: #eee; color: #000;}
				.footer { font-size: 14px; font-weight: 700; padding: 5px; }
				.tlpamber { background: #333; color: #FFBF00; text-align: right; }
				.date { background: #333; color: #FFF; text-align: left; }
				.TruePositive { background: #e61c5d; width: 200px; color: #FFF}
				.TrueNegative { background: #ffd2bb; width: 200px;  color: #FFF}
				.FalsePositive { background: #ff8b6a; width: 200px;  color: #FFF}
				.FalseNegative { background: #65c6c4; width: 200px;  color: #FFF}
				.Undecided { background: #bbbbbb; width: 200px;  color: #FFF}
				.NoActionable { background: #408ab4; width: 200px;  color: #FFF}
				.Informational { background: #fab95b; width: 200px;  color: #FFF}
			</style>
			<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700" rel="stylesheet"/>
			<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
			<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
			<meta charset="utf-8"/>
			<script type="text/javascript">

			google.charts.load('current', {'packages':['corechart']});
			google.charts.setOnLoadCallback(drawChart);

			function drawChart() {
			var data = google.visualization.arrayToDataTable([
			['Status', 'Value'],
			['TP', """ + str(Stats["Ratio"]["TP"]) + """],
			['TN', """ + str(Stats["Ratio"]["TN"]) + """],
			['FP', """ + str(Stats["Ratio"]["FP"]) + """],
			['FN', """ + str(Stats["Ratio"]["FN"]) + """],
			['Undecided', """ + str(Stats["Ratio"]["Undecided"]) + """],
			['NoActionable', """ + str(Stats["Ratio"]["NoActionable"]) + """],
			['Informational', """ + str(Stats["Ratio"]["Informational"]) + """]
			]);

			var options = {
				title: "Breakdown of Alerts by Types",
				width: 500,
				height: 500,
				pieHole: 0.3,
				slices: [{color: '#e61c5d'}, {color: '#ffd2bb'}, {color: '#ff8b6a'}, {color: '#65c6c4'}, {color: '#bbbbbb'}, {color: '#408ab4'}, {color: '#5ab95b'}],
				chartArea: { left:30, top:50, width:'90%', height:'90%' },
				legend: {position: 'right'},
				fontSize: 14
			};
			var chart = new google.visualization.PieChart(document.getElementById('ratio'));
			chart.draw(data, options);
			}
			</script>

			<script type="text/javascript">

			google.charts.load('current', {'packages':['corechart']});
			google.charts.setOnLoadCallback(drawChart);

			function drawChart() {
			var data = google.visualization.arrayToDataTable([
			['Status', 'Value', {role: 'style'}],
			['Critical', """ + str(Stats["Alert_Priority"]["Critical"]) + """, '#e61c5d'],
			['High', """ + str(Stats["Alert_Priority"]["High"]) + """, '#ff8b6a'],
			['Medium', """ + str(Stats["Alert_Priority"]["Medium"]) + """, '#65c6c4'],
			['Low', """ + str(Stats["Alert_Priority"]["Low"]) + """, '#408ab4'],
			['Informational', """ + str(Stats["Alert_Priority"]["Informational"]) + """, '#5ab95b'],
			]);

			var options = {
				title: "Breakdown of Alerts by Priority",
				width: 500,
				height: 250,
				legend: {position: 'none'},
				chartArea: { left:100, top:50, width:'100%', height: '70%' },
				fontSize: 14
			};
			var chart = new google.visualization.BarChart(document.getElementById('alert-priority'));
			chart.draw(data, options);
			}
			</script>

			<script type="text/javascript">

			google.charts.load('current', {'packages':['corechart']});
			google.charts.setOnLoadCallback(drawChart);

			function drawChart() {
			var data = google.visualization.arrayToDataTable([
			['Status', 'Value', {role: 'style'}],
			['Done', """ + str(Stats["Alert_Status"]["Done"]) + """, '#65c6c4'],
			['NoActions', """ + str(Stats["Alert_Status"]["NoActions"]) + """, '#ff8b6a'],
			['In-Progress', """ + str(Stats["Alert_Status"]["In-Progress"]) + """, '#408ab4'],
			['Pending', """ + str(Stats["Alert_Status"]["Pending"]) + """, '#f16821']
			]);

			var options = {
				title: "Status of Alerts",
				width: 500,
				height: 250,
				legend: {position: 'none'},
				chartArea: { left:100, top:40, width:'100%', height: '70%' },
				fontSize: 14
			};
			var chart = new google.visualization.ColumnChart(document.getElementById('alert-status'));
			chart.draw(data, options);
			}
			</script>

			<script type="text/javascript">

			google.charts.load('current', {'packages':['corechart']});
			google.charts.setOnLoadCallback(drawChart);

			function drawChart() {
			var data = google.visualization.arrayToDataTable([
			['Status', 'Value', {role: 'style'}],
			['TP', """ + str(Stats["Time_Spent"]["TP"]) + """, '#e61c5d'],
			['TN', """ + str(Stats["Time_Spent"]["TN"]) + """, '#ffd2bb'],
			['FP', """ + str(Stats["Time_Spent"]["FP"]) + """, '#ff8b6a'],
			['FN', """ + str(Stats["Time_Spent"]["FN"]) + """, '#65c6c4'],
			['Undecided', """ + str(Stats["Time_Spent"]["Undecided"]) + """, '#bbbbbb'],
			['NoActionable', """ + str(Stats["Time_Spent"]["NoActionable"]) + """, '#408ab4'],
			['Informational', """ + str(Stats["Time_Spent"]["Informational"]) + """, '#5ab95b']
			]);

			var options = {
				title: "Hours Spent per Alert Type",
				width: 500,
				height: 250,
				legend: {position: 'none'},
				chartArea: { left:30, top:40, width:'80%', height: '70%' },
				fontSize: 14
			};
			var chart = new google.visualization.ColumnChart(document.getElementById('time-spent'));
			chart.draw(data, options);
			}
			</script>

			<script type="text/javascript">

			google.charts.load('current', {'packages':['corechart']});
			google.charts.setOnLoadCallback(drawChart);

			function drawChart() {
			var data = google.visualization.arrayToDataTable(""" + str(Data_Source_Table) + """);

			var options = {
				title: "Data Sources Efficiency Overview",
				width: 1000,
				height: 500,
				legend: {position: 'right'},
				bar: { groupWidth: "75%" },
				bars: 'horizontal',
				chartArea: { left:300, top:100, width:'50%', height:'70%' }
			};
			var chart = new google.visualization.BarChart(document.getElementById('data-sources'));
			chart.draw(data, options);
			}
			</script>
		</head>
		"""
		HTML = HTML + HEAD
		# Add body to HTML
		HTML += """
		<body>
		<table width="100%">
		<tr>
			<td align="left" width="50%">
				<h1>Daily Summary</h1>
			</td>
			<td align="right" width="50%">
				<img align="right" width="160.7px" height="45px" src=""" + CONFIG[Organization]["logo"] + """>
			</td>
		</tr>
		</table>
		"""
		# Add State of the SOC section
		State_Of_The_Soc = """"""
		if CONFIG[Organization]["visualizations"]["analyst_time"] == True:
			State_Of_The_Soc += """
				<table width="100%">
				<tr><th colspan='12'>State Of The SOC</th></tr>
				<tr>
					<td class="toptable">
						<div id="ratio" style="width:500px; height:500px;"></div>
					</td>
					<td class="toptable">
						<table width="100%">
							<tr>
								<div id="alert-priority" style="width:500px; height:250px;"></div>
							</tr>
							<tr>
								<div id="alert-status" style="width:500px; height:250px;"></div>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
				<td class="toptable">
					<div id="time-spent" style="width:500px; height:250px;"></div>
				</td>
				<td class="toptable">
					<table width="100%">
						<tr><th id='Statistics' colspan='2'>All-time Statistics</th></tr>
						<tr><td class='TruePositive'><a href='#TruePositive' class='aAnker'>True Positive</a></td><td class='value'>""" + str(Stats["Ratio"]["TP"]) + """</td></tr>
						<tr><td class='TrueNegative'><a href='#TrueNegative' class='aAnker'>True Negative</a></td><td class='value'>""" + str(Stats["Ratio"]["TN"]) + """</td></tr>
						<tr><td class='FalsePositive'><a href='#FalsePositive' class='aAnker'>False Positive</a></td><td class='value'>""" + str(Stats["Ratio"]["FP"]) + """</td></tr>
						<tr><td class='FalseNegative'><a href='#FalseNegative' class='aAnker'>False Negative</a></td><td class='value'>""" + str(Stats["Ratio"]["FN"]) + """</td></tr>
						<tr><td class='Undecided'><a href='#Undecided' class='aAnker'>Undecided</a></td><td class='value'>""" + str(Stats["Ratio"]["Undecided"]) + """</td></tr>
						<tr><td class='NoActionable'><a href='#NoActionable' class='aAnker'>Without Actionable</a></td><td class='value'>""" + str(Stats["Ratio"]["NoActionable"]) + """</td></tr>
						<tr><td class='Informational'><a href='#Informational' class='aAnker'>Informational</a></td><td class='value'>""" + str(Stats["Ratio"]["Informational"]) + """</td></tr>
					</table>
				</td>
			</tr>"""
		else:
			State_Of_The_Soc += """
				<table width="100%">
					<tr><th colspan='12'>State Of The SOC</th></tr>
					<tr>
						<td class="toptable">
							<div id="ratio" style="width:500px; height:500px;"></div>
						</td>
						<td class="toptable">
							<table width="100%">
								<tr>
									<div id="alert-priority" style="width:500px; height:250px;"></div>
								</tr>
								<tr>
									<div id="alert-status" style="width:500px; height:250px;"></div>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table width="100%">
					<tr><th id='Statistics' colspan='12'>All-time Statistics</th></tr>
					<tr>
						<td class="toptable">
							<table width="100%">
								<tr><td class='TruePositive'><a href='#TruePositive' class='aAnker'>True Positive</a></td><td class='value'>""" + str(Stats["Ratio"]["TP"]) + """</td></tr>
								<tr><td class='TrueNegative'><a href='#TrueNegative' class='aAnker'>True Negative</a></td><td class='value'>""" + str(Stats["Ratio"]["TN"]) + """</td></tr>
								<tr><td class='FalsePositive'><a href='#FalsePositive' class='aAnker'>False Positive</a></td><td class='value'>""" + str(Stats["Ratio"]["FP"]) + """</td></tr>
							</table>
						</td>
						<td class="toptable">
							<table width="100%">
								<tr><td class='Undecided'><a href='#Undecided' class='aAnker'>Undecided</a></td><td class='value'>""" + str(Stats["Ratio"]["Undecided"]) + """</td></tr>
								<tr><td class='NoActionable'><a href='#NoActionable' class='aAnker'>Without Actionable</a></td><td class='value'>""" + str(Stats["Ratio"]["NoActionable"]) + """</td></tr>
								<tr><td class='Informational'><a href='#Informational' class='aAnker'>Informational</a></td><td class='value'>""" + str(Stats["Ratio"]["Informational"]) + """</td></tr>
							</table>
						</td>
					</tr>
				</table>"""
		State_Of_The_Soc+= """</table>
		<table width="100%">
			<tr>
				<div id="data-sources" style="width:1000px; height:500px;"></div>
			</tr>
		</table>
		<table width="100%">
		<tr class="footer">
			<td align="left" width="50%">
				<span class="date"> """ + DATE + """ </span>	
			</td>
			<td align="right" width="50%">
				<span class="tlpamber">[ TLP: AMBER ]</span>
			</td>
		</tr>
		</table>
		</br>
		</br>
		</br>
		"""
		HTML += State_Of_The_Soc
		HTML += """
		<table width="100%">
		<tr><th id='Statistics' colspan='2'>Daily Statistics</th></tr>
		<tr>
			<td class="toptable">
				<table width="100%">
					<tr><td class='TruePositive'><a href='#TruePositive' class='aAnker'>True Positive</a></td><td class='value'>""" + str(Stats["Daily_Ratio"]["TP"]) + """</td></tr>
					<tr><td class='TrueNegative'><a href='#TrueNegative' class='aAnker'>True Negative</a></td><td class='value'>""" + str(Stats["Daily_Ratio"]["TN"]) + """</td></tr>
					<tr><td class='FalsePositive'><a href='#FalsePositive' class='aAnker'>False Positive</a></td><td class='value'>""" + str(Stats["Daily_Ratio"]["FP"]) + """</td></tr>
					<tr><td class='FalseNegative'><a href='#FalseNegative' class='aAnker'>False Negative</a></td><td class='value'>""" + str(Stats["Daily_Ratio"]["FN"]) + """</td></tr>
					<tr><td class='Undecided'><a href='#Undecided' class='aAnker'>Undecided</a></td><td class='value'>""" + str(Stats["Daily_Ratio"]["Undecided"]) + """</td></tr>
					<tr><td class='NoActionable'><a href='#NoActionable' class='aAnker'>Without Actionable</a></td><td class='value'>""" + str(Stats["Daily_Ratio"]["NoActionable"]) + """</td></tr>
					<tr><td class='Informational'><a href='#Informational' class='aAnker'>Informational</a></td><td class='value'>""" + str(Stats["Daily_Ratio"]["Informational"]) + """</td></tr>
				</table>
			</td>
			<td class="toptable">
				<table width="100%">
					<tr><td class='TruePositive'><a href='#Morning' class='aAnker'>Morning</a></td><td class='value'>""" + str(Stats["Shift"]["Morning"]) + """</td></tr>
					<tr><td class='TrueNegative'><a href='#Evening' class='aAnker'>Evening</a></td><td class='value'>""" + str(Stats["Shift"]["Evening"]) + """</td></tr>
					<tr><td class='FalsePositive'><a href='#Night' class='aAnker'>Night</a></td><td class='value'>""" + str(Stats["Shift"]["Night"]) + """</td></tr>
				</table>
			</td>
		</tr>
		</table>
		"""
		# Add Morning shift
		HTML += """
		<table width="100%">
		<tr><th id='Morning' class="TruePositive" colspan='2'>Morning</th></tr>
		""" + Summary["Morning"] + """
		</table>
		"""
		# Add Evening shift
		HTML += """
		<table width="100%">
		<tr><th id='Evening' class="TrueNegative" colspan='2'>Evening</th></tr>
		""" + Summary["Evening"] + """
		</table>
		"""
		# Add Night shift
		HTML += """
		<table width="100%">
		<tr><th id='Night' class="FalsePositive" colspan='2'>Night</th></tr>
		""" + Summary["Night"] + """
		</table>
		"""
		HTML += """
		</body>
		</html>
		"""

		# Create the HTML file
		HTML_Summary_Name = CONFIG[Organization]["code"] + "_" + DATE + ".html"
		with open(HTML_Summary_Name, "w") as summary:
			summary.write(HTML)
		
		# Commented until the xhtml2pdf issue gets resolved
		# Create PDF using xhtml2pdf
		# PDF_Summary_Name = CONFIG[Organization]["code"] + "_" + DATE + ".pdf"
		# with open(PDF_Summary_Name, "w+b") as PDF_File:
		# 	pisa_status = pisa.CreatePDF(HTML, dest=PDF_File)
		
		# Commented until the PDFKit issue is resolved
		# Create PDF from HTML
		# PDF_Summary_Name = CONFIG[Organization]["code"] + "_" + DATE + ".pdf"
		# pdfkit.from_file(HTML_Summary_Name, PDF_Summary_Name, options={
		# 	"page-size": "A4",
		# 	"no-stop-slow-scripts": None,
		# 	"javascript-delay": "5000"
		# })

		# Send Email
		email = MIMEMultipart()
		email['From'] = CONFIG[Organization]["from_email"]
		email['To'] = CONFIG[Organization]["to_email"] 
		email['Subject'] = "Daily Summary"
		body = CONFIG[Organization]["code"] + "_" + DATE
		email.attach(MIMEText(body, 'plain'))
		
		# open the HTML file to be sent
		attachment = open(HTML_Summary_Name, "rb")
		post_message = MIMEBase('application', 'octet-stream')
		post_message.set_payload((attachment).read())
		encoders.encode_base64(post_message)
		post_message.add_header('Content-Disposition', "attachment; filename= %s" % HTML_Summary_Name)
		email.attach(post_message)
		
		# Commented until the PDFKit issue is resolved
		# open the PDF file to be sent <commented because of poor support from wkhtmltopdf> 
		# attachment = open(PDF_Summary_Name, "rb")
		# post_message = MIMEBase('application', 'octet-stream')
		# post_message.set_payload((attachment).read())
		# encoders.encode_base64(post_message)
		# post_message.add_header('Content-Disposition', "attachment; filename= %s" % PDF_Summary_Name)
		# email.attach(post_message)
		
		# Create SMTP session
		send = smtplib.SMTP('smtp.gmail.com', 587)
		send.starttls()
		send.login(CONFIG[Organization]["from_email"], os.environ.get(CONFIG[Organization]["pass"]))
		text = email.as_string()
		
		# Send the mail and terminate session
		send.sendmail(CONFIG[Organization]["from_email"], CONFIG[Organization]["to_email"], text)
		send.quit()
