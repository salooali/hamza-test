import time
import boto3
from .consts import *


class aws_ip_block:

    
    logger = aws_profile_name = waf_type = aws_region = ipset_id = cidr_list = aws_client = change_token = None


    def __init__(self) -> None:
        pass


    def __init__(self, logger, aws_profile_name, aws_region, waf_type, ipset_id, cidr_list):
        self.logger = logger
        self.aws_profile_name = aws_profile_name
        self.aws_region = aws_region
        self.waf_type = waf_type
        self.ipset_id = ipset_id
        self.cidr_list = cidr_list


    def aws_client_init(self):
        session = boto3.Session(profile_name=self.aws_profile_name)
        if self.waf_type in consts.get('waf_type_allowed_values'):
            self.aws_client = session.client(self.waf_type, region_name=self.aws_region)
        else:
            self.logger.error('WAF type {} is not valid. Select one out of {}...'.format(self.waf_type, consts.get('waf_type_allowed_values')))
    

    def update_ip_set(self):
        self.aws_client.update_ip_set(
            IPSetId=self.ipset_id,
            ChangeToken=self.change_token,
            Updates=self.cidr_list
        )


    def get_change_token(self):
        self.change_token = self.aws_client.get_change_token().get('ChangeToken')


    def get_change_token_status(self):
        response = ''
        iter = 1
        while (not response == 'INSYNC'):
            self.logger.info('Checking if change has been propagated == {}...'.format(response))
            response = self.aws_client.get_change_token_status(ChangeToken=self.change_token).get('ChangeTokenStatus')
            
            if response == 'INSYNC': break
            
            self.logger.info('CT: {} sleeping for 5 seconds. May take 2-5 minutes. However GUI console should be displaying updated result...'.format(self.change_token))
            time.sleep(5)
            iter += 1
        self.logger.info('Change has been successfully propagated in {} seconds == {}...'.format(iter*5, response))


    def main(self):
        self.aws_client_init()
        self.get_change_token()
        self.update_ip_set()
        self.get_change_token_status()