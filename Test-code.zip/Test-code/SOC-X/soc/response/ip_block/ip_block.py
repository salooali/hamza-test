import ipaddress
from pprint import pprint
from . import aws_ip_block


class ip_block:


    client = None
    respond_on = None
    config = None
    ip_file = None
    logger = None
    aws_format_ip_list = None
    action = None


    def __init__(self, logger, input_file, action, respond_on):
        self.ip_file = input_file
        self.logger = logger
        self.action = action
        self.respond_on = respond_on


    def ip_file_to_aws_format(self):
        self.aws_format_ip_list = []
        with open(self.ip_file) as ipf:
            for line in ipf.readlines():
                # strip extra line endings
                line = line.replace('\n', '')
                line = line.replace('\r', '')
                line = line.replace(',', '')
                is_ipv4 = is_ipv6 = False
                # without CIDR notated IPs
                if '/' not in line:
                    # ipv4/6 check
                    try:
                        ip_v = ipaddress.ip_address(line).version
                        if ip_v == 4: is_ipv4 = True
                        elif ip_v == 6: is_ipv6 = True
                        else: pass
                        self.logger.debug('{} is IPv{}'.format(line, ip_v))
                    except Exception as e:
                        self.logger.exception('Exception {} occurred in IP {}'.format(e, line))
                    # is CIDR notation
                    if is_ipv4: line += '/32'
                    elif is_ipv6: line += '/128'
                    else: pass
                    self.logger.debug('CIDR notation {}...'.format(line))
                # checks for CIDR notation check don't yet exist
                elif '/' in line:
                    if '.' in line: is_ipv4 = True
                    elif ':' in line: is_ipv6 = True
                    else: pass
                # aws format dict
                self.aws_format_ip_list.append({
                    'Action': self.action,
                    'IPSetDescriptor': {
                        'Type': 'IPV4' if is_ipv4 else 'IPV6',
                        'Value': line
                    }
                })
        pprint(self.aws_format_ip_list)


    def update_aws_waf(self, aws_profile_name, aws_region, waf_type, ipset_id):
        aws_ip_block.aws_ip_block(self.logger, aws_profile_name, aws_region, waf_type, ipset_id, self.aws_format_ip_list).main()


    def main(self, aws_profile_name, aws_region, waf_type, ipset_id):
        if self.respond_on == "aws":
            self.ip_file_to_aws_format()
            self.update_aws_waf(aws_profile_name, aws_region, waf_type, ipset_id)