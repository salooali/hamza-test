consts = {
    'waf_type_allowed_values': [
        'waf-regional'
    ]
}