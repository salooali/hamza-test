import re
import sys
import boto3


class aws_lb_waf_attachment:


    logger = None
    loadbalancer_id = loadbalancer_arn = None
    elbv2_c = elbv2_regions = elbv2_found_region = None
    waf_reg_c = waf_reg_regions = None
    waf_v2_c = waf_v2_regions = None
    aws_profile_name = None


    def __init__(self, logger, profile_name, aws_region=None, loadbalancer_id=None, loadbalancer_arn=None) -> None:
        self.logger = logger
        self.aws_profile_name = profile_name
        self.elbv2_regions = boto3.session.Session().get_available_regions('elbv2')
        self.waf_reg_regions = boto3.session.Session().get_available_regions('waf-regional')
        self.waf_reg_regions = boto3.session.Session().get_available_regions('wafv2')
        if loadbalancer_arn is not None:
            self.loadbalancer_arn = loadbalancer_arn
            self.elbv2_found_region = aws_region
            # self.loadbalancer_id = str(self.loadbalancer_arn).split('/')[-2]
        if self.loadbalancer_arn is None and loadbalancer_id is not None:
            self.loadbalancer_arn = self.get_lb_arn_from_lb_id(loadbalancer_id)


    def get_lb_arn_from_lb_id(self, loadbalancer_id):
        lb_arn = None
        self.parse_loadbalancer_id(loadbalancer_id)
        for region in self.elbv2_regions:
            lb_arn = self.find_lb_in_region(region)
            if lb_arn is not None: 
                # if lb found in a region
                # self.loadbalancer_arn = lb_arn
                self.elbv2_found_region = region
                self.logger.info('Found LB {} in region {}'.format(loadbalancer_id, region))
                break 
        if lb_arn is None:
            self.logger.error('LB {} not found in any region of current AWS profile {}'.format(self.loadbalancer_id, self.aws_profile_name))
            sys.exit(1)
        return lb_arn


    def find_lb_in_region(self, region):
        resource_arn = None
        session = boto3.Session(profile_name=self.aws_profile_name)
        self.elbv2_c = session.client('elbv2', region_name=region)
        try:
            resource_arn = self.elbv2_c.describe_load_balancers(Names=[self.loadbalancer_id])['LoadBalancers'][0]['LoadBalancerArn']
        except Exception as e:
            self.logger.error('LB Not found in region {0}\nException {1} occurred in find_lb_in_region {0}...'.format(region, e))
        return resource_arn


    def parse_loadbalancer_id(self, lb_id):
        if lb_id is None or lb_id == "":
            # if no LB ID is passed, return
            self.logger.warn('Ending method prematurely because lb ID is None or empty -- LB ID: {}'.format(lb_id))
            return
        self.logger.info('Parsing LB ID: {}'.format(lb_id))
        if '/' in lb_id:
            self.loadbalancer_id = re.findall(r'/(.*)/', lb_id)
        else:
            self.loadbalancer_id = lb_id
        self.logger.info('Parsed LB ID: {}'.format(self.loadbalancer_id))


    def check_waf_status_for(self, waf_type):
        session = boto3.Session(profile_name=self.aws_profile_name)
        aws_waf_client = session.client(waf_type, region_name=self.elbv2_found_region)
        response = aws_waf_client.get_web_acl_for_resource(ResourceArn=self.loadbalancer_arn)
        if response is not None:
            if waf_type == 'waf-regional':
                self.logger.info('WAF Regional attachment found with WAF {} ({}) ==>  LB {}'.format(response['WebACLSummary']['Name'], response['WebACLSummary']['WebACLId'], self.loadbalancer_arn))
            elif waf_type == 'wafv2':
                self.logger.info('WAFv2 attachment found with WAF {}({}) ==>  LB {}'.format(response['WebACL']['Name'], response['WebACL']['Id'], self.loadbalancer_arn))
        else:
            self.logger.error('No {} attachment found for LB {}...'.format(waf_type, self.loadbalancer_arn))
        return response


    def waf_attachment_status(self):
        response = self.check_waf_status_for('waf-regional')
        if response is None:
            self.check_waf_status_for('wafv2')