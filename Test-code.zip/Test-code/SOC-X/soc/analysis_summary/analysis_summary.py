import os
import logging
import openpyxl
from .consts import *
from pprint import pprint
from datetime import datetime, timedelta


class general_analysis_summary:


    active_collab = None
    date_today = ''
    client = ''
    input_file = ''
    output_file = '.output.txt'
    logger = ''
    analysis_date_format = '%Y-%m-%d'
    date_format = '%Y-%m-%d'
    time_format = '%Y-%m-%dT%H:%M:%SZ'
    summary_type = ''
    min_row = -1
    max_row = -1
    header_dict = {}
    header_list = []
    required_columns = [
        'Shift',
        'Analyst',
        'Analysis Date',
        'Datasource',
        'Alert ID(s)',
        'Alert Title',
        'Alert Details',
        'Time of first event',
        'Time of last event',
        'Alert Priority',
        'Alert Status',
        'Analysis Status',
        'Ticket ID',
        'Action Items',
        'Time Spent',
        'Events Count',
        'Alerts Count'
    ]
    non_empty_columns = [
        'Shift',
        'Analyst',
        'Analysis Date',
        'Alert ID(s)',
        'Datasource',
        'Alert Title',
        'Alert Details',
        'Time of first event',
        'Time of last event',
        'Alert Priority',
        'Alert Status',
        'Analysis Status',
        'Time Spent',
        'Events Count',
        'Alerts Count'
    ]
    client_allowed_values = consts.get('client_allowed_values')
    summary_type_allowed_values = consts.get('summary_type_allowed_values')
    validation_successful = False


    def __init__(self, date_today, client, summary_type, input_file, output_file, logger, active_collab=None):
        self.logger = logger
        self.active_collab = active_collab
        self.date_today = date_today
        self.client = client
        self.input_file = input_file
        self.output_file = output_file
        self.summary_type = summary_type


    def get_date_today_in_str(self):
        if isinstance(self.date_today, datetime):
            return datetime.strftime(self.date_today, self.analysis_date_format)
        else: return datetime.strftime(datetime.strptime(self.date_today, self.analysis_date_format), self.analysis_date_format)


    def validate_date(self):
        try:
            datetime.strptime(self.date_today, self.date_format)
            self.logger.info('Date time {} is in correct format...'.format(self.date_today))
            self.validation_successful = True
        except Exception as e:
            self.logger.error('Date time {} is not in correct format {}...'.format(self.date_today, self.date_format))
            self.validation_successful = False



    def validate_time_v2(self, input_file, column_name):

        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for value in self.get_all_values_from_column(active_sheet, column_name):
            try:
                datetime.strptime(value, self.time_format)
                self.logger.info('Time {} is in correct format...'.format(value))
                self.validation_successful = True
            except Exception as e:
                self.logger.error('Time {} is not in correct format {}...'.format(value, self.time_format))
                self.validation_successful = False
        if not validation_successful:
            self.logger.error('Try changing the time column format to "Plain Text" and try again...')
        wb_obj.close()
        return validation_successful


    def validate_time(self, time_vals):
        try:
            for val in time_vals:
                datetime.strptime(val, self.time_format)
                self.logger.info('Time {} is in correct format...'.format(val))
                self.validation_successful = True
        except Exception as e:
            self.logger.error('Time {} is not in correct format {}...'.format(val, self.time_format))
            self.validation_successful = False


    def validate_summary_type(self):
        if self.summary_type in self.summary_type_allowed_values:
            self.logger.info('summary type validation was successful...')
            self.validation_successful = True
        else:
            self.logger.error('{} is not a valid summary type...'.format(self.summary_type))
            self.validation_successful = False


    def validate_client(self):
        if self.client in self.client_allowed_values:
            self.logger.info('client validation was successful...')
            self.validation_successful = True
        else:
            self.logger.error('{} is not a valid client...'.format(self.client))
            self.validation_successful = False


    def validate_file_exists(self, file):
        if os.path.isfile(file):
            self.logger.info('file {} exists...'.format(file))
            self.validation_successful = True
        else: 
            self.validation_successful = False
            self.logger.error('file {} does not exist...'.format(file))


    def validate_required_columns(self):
        for item in self.required_columns:
            if item not in self.header_list:
                self.validation_successful = False
                self.logger.error('{} required column is not present...'.format(item))
                break
    
    
    def get_all_values_from_column(self, active_sheet, column_name, min_row=-1, max_row=-1):
        col_vals = []
        # self.logger.info(active_sheet.max_row)
        # exit()
        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for item in active_sheet.iter_cols(min_col=self.header_dict[column_name]+1, max_col=self.header_dict[column_name]+1, min_row=min_row, max_row=max_row, values_only=True):
                self.logger.debug('Getting all values from column {}...'.format(column_name))
                self.logger.debug(item)
                for i in item:
                    col_vals.append(i)
        self.logger.debug('Get all values from column {}:'.format(column_name))
        pprint(col_vals)
        return col_vals
    

    def validate_non_empty_columns(self, active_sheet):
        for col in self.non_empty_columns:
            for item in active_sheet.iter_cols(min_col=self.header_dict[col]+1, max_col=self.header_dict[col]+1, values_only=True):
                self.logger.debug('Validating column {}...'.format(col))
                self.logger.debug(item)
                for idx, i in enumerate(item):
                    if i is None:
                        self.logger.error('{} at idx {}...'.format(i, idx+1))
                        self.validation_successful = False
                        break
                if not self.validation_successful:
                    self.logger.error('Column {} has some empty values...'.format(col))
                    return


    def validate_workbook(self, file):
        try:
            wb_obj = openpyxl.load_workbook(file)
            active_sheet = wb_obj['Analysis_Summary']
            self.logger.info('Right sheet exists in the XLSX file...')
            self.validation_successful = True
            if self.validation_successful:
                self.set_header(active_sheet)
                self.validate_required_columns()
                if self.validation_successful:
                    self.validate_non_empty_columns(active_sheet)
                    # exit(1)
                    # if self.validation_successful:
                    #     self.validate_time(self.get_all_values_from_column(active_sheet, 'Time of first event'))
                    #     if self.validation_successful:
                    #         self.validate_time(self.get_all_values_from_column(active_sheet, 'Time of last event'))
            wb_obj.close()
        except Exception as e:
            self.logger.error('Right sheet doesn\'t exist...')
            self.validation_successful = False
        

    def validate_input_file(self):
        self.validate_file_exists(self.input_file)
        if self.validation_successful:
            # check if right sheet with the right name exists in the input file
            if self.validation_successful:
                # if active sheet has the required columns
                self.validate_workbook(self.input_file)


    def run_validate(self):
        self.validate_date()
        if self.validation_successful: self.validate_summary_type()
        else: return
        if self.validation_successful: self.validate_client()
        else: return
        if self.validation_successful: self.validate_input_file()
        else: return
        if self.validation_successful: self.validate_analysis_date(self.input_file, 'Analysis Date')
        else: return
        if self.validation_successful: self.validate_alert_ids(self.input_file, 'Alert ID(s)')
        else: return
        if self.validation_successful: self.validate_ticket_ids(self.input_file, 'Ticket ID')
        else: return
        if self.validation_successful: self.validate_alerts_count(self.input_file, 'Alerts Count')
        else: return
        if self.validation_successful: self.validate_analysis_status(self.input_file, 'Analysis Status')
        else: return
        if self.validation_successful: self.validate_alert_status(self.input_file, 'Alert Status')
        else: return
        if self.validation_successful: self.validate_alert_priority(self.input_file, 'Alert Priority')
        else: return
        if self.validation_successful: self.validate_alert_title(self.input_file, 'Alert Title')
        else: return
        if self.validation_successful: self.validate_time_spent(self.input_file, 'Time Spent')
        else: return
        if self.validation_successful: self.validate_time_v2(self.input_file, 'Time of first event')
        else: return
        if self.validation_successful: self.validate_time_v2(self.input_file, 'Time of last event')
        else: return

        if not self.validation_successful: self.logger.error('Validation failed...')
        else: self.logger.info('Validation successful...')
        # exit(1)


    def append_to_output_file(self, str_to_append):
        with open(self.output_file, 'a') as o:
            o.write(str(str_to_append))

    
    def set_header(self, active_sheet):
        self.header_dict = {
            # header field value: header column index
            # shift: 0
        }
        self.header_list = [
            # header field value
        ]
        index = 0
        for row in active_sheet.iter_rows(1,1):
            for cell in row:
                self.header_dict[cell.value] = index
                self.header_list.append(cell.value)
                index += 1
            print()
            break
        self.logger.info('Printing header:')
        self.logger.info(self.header_list)
        pprint(self.header_dict)


    def validate_date_v2(self, value, date_format):
        validation_successful = False
        try:
            datetime.strptime(value, date_format)
            self.logger.debug('Date time {} is in correct format...'.format(value))
            self.validation_successful = True
            validation_successful = True
        except Exception as e:
            self.logger.error('Date time {} is not in correct format {}...'.format(value, date_format))
            self.validation_successful = False
            validation_successful = False
        return validation_successful


    def validate_alert_details(self, value):
        # value = str(value)
        # value = self.sanitize_string(value)
        # return value
        pass


    def value_in_allowed_values(self, value, allowed_values_list):
        return value in allowed_values_list

    
    def validate_time_spent(self, input_file, column_name):
        validation_successful = True
        max = timedelta(hours=27) if self.summary_type == 'merged' else timedelta(hours=10)
        total = timedelta(hours=0)
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']

        for index, row in enumerate(active_sheet.iter_rows(2, values_only=True)):
            value = row[self.header_dict['Time Spent']]
            if type(value) == timedelta:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format):
                    total += value
            else:
                self.logger.error('Time spent "{}" is in incorrect format {}. It should be "timedelta" at row {}...'.format(value, type(value), index))
                self.validation_successful = False
                validation_successful = False
                break
            # shift or day time spent calcs validation
            if total > max:
                self.logger.error('Total time spent {}. More than shift total time {} spent...'.format(total, max))
                self.validation_successful = False
                validation_successful = False
                break
        if not validation_successful:
            self.logger.error('Update and try again...')
        wb_obj.close()
        return validation_successful


    def sanitize_string(self, value):
        value = str(value)
        value = value.replace('\u200b','')
        value = value.lstrip()
        value = value.rstrip()
        return value

    
    def validate_alert_title(self, input_file, column_name):
        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for idx, value in enumerate(self.get_all_values_from_column(active_sheet, column_name)):
            value = self.sanitize_string(value)
            if value == "None" or value == "" or value == " " or value == "\n":
                self.logger.error('Forbidden value "{}" at idx {} of column {}...'.format(value, idx+1, column_name))
                validation_successful = False
            # if str(value)[0] in [' ', '\n']:
            #     self.logger.error('Alert title "{}" is incorrect as it contains forbidden starting characters...'.format(value))
            #     self.validation_successful = False
            #     validation_successful = False
            #     break
            # else:
                # self.logger.debug('Alert title "{}" is correct...'.format(value))
            self.logger.debug('Alert title "{}" is correct...'.format(value))
        self.validation_successful = validation_successful
        if not validation_successful:
            self.logger.error('Update and try again...')
        wb_obj.close()
        return validation_successful


    def get_time_to_log(self, analyst, column_name='Time Spent'):
        total = timedelta(hours=0)
        wb_obj = openpyxl.load_workbook(self.input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for index, row in enumerate(active_sheet.iter_rows(2, values_only=True)):
            # self.logger.debug(row)
            if self.summary_type == 'merged':
                if row[self.header_dict['Analyst']].lower() == analyst.lower() and datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) == self.date_today:
                    value = row[self.header_dict[column_name]]
                    total += value
                # self.logger.debug(value)
            else:
                if row[self.header_dict['Shift']].lower() == self.summary_type and row[self.header_dict['Analyst']].lower() == analyst.lower() and datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) == self.date_today:
                    value = row[self.header_dict[column_name]]
                    total += value
        wb_obj.close()
        return total

    
    def validate_alert_priority(self, input_file, column_name):
        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for value in self.get_all_values_from_column(active_sheet, column_name):
            if self.value_in_allowed_values(value, consts.get('alert_priority_allowed_values')):
                self.logger.debug('Alert priority {} is correct...'.format(value))
            else:
                self.logger.error('Alert priority {} is incorrect...'.format(value))
                self.validation_successful = False
                validation_successful = False
                break
        if not validation_successful:
            self.logger.error('Try adding correct value and try again...')
        wb_obj.close()
        return validation_successful

    
    def validate_alert_status(self, input_file, column_name):
        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for value in self.get_all_values_from_column(active_sheet, column_name):
            if self.value_in_allowed_values(value, consts.get('alert_status_allowed_values')):
                self.logger.debug('Alert status {} is correct...'.format(value))
            else:
                self.logger.error('Alert status {} is incorrect...'.format(value))
                self.validation_successful = False
                validation_successful = False
                break
        if not validation_successful:
            self.logger.error('Try adding correct value and try again...')
        wb_obj.close()
        return validation_successful

    
    def validate_analysis_status(self, input_file, column_name):
        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for value in self.get_all_values_from_column(active_sheet, column_name):
            if self.value_in_allowed_values(value, consts.get('analysis_status_allowed_values')):
                self.logger.debug('Analysis status {} is correct...'.format(value))
            else:
                self.logger.error('Analysis status {} is incorrect...'.format(value))
                self.validation_successful = False
                validation_successful = False
                break
        if not validation_successful:
            self.logger.error('Try adding correct value and try again...')
        wb_obj.close()
        return validation_successful

    
    def validate_alerts_count(self, input_file, column_name):
        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for idx, value in enumerate(self.get_all_values_from_column(active_sheet, column_name)):
            if type(value) == int or type(value) == float:
                self.logger.debug('Alerts count {} is in correct format "int"/"float" at row {}...'.format(value, idx))
            elif type(value) == str:
                int(value)
                self.logger.debug('Alerts count {} is in correct format "int"/"float" at row {}...'.format(value, idx))
            else:
                self.logger.error('Alerts count {} is not in correct format "int"/"float" at row {}...'.format(value, idx))
                self.validation_successful = False
                validation_successful = False
                break
        if not validation_successful:
            self.logger.error('Try changing the relevant column format to "Number" and try again...')
        wb_obj.close()
        return validation_successful

    
    def validate_ticket_ids(self, input_file, column_name):
        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for value in self.get_all_values_from_column(active_sheet, column_name):
            if value is None or type(value) == int:
                self.logger.debug('Ticket ID(s) {} is in correct format "str"...'.format(value))
            elif type(value) == float:
                self.logger.error('Ticket ID(s) {} is not in correct format "str"...'.format(value))
                self.validation_successful = False
                validation_successful = False
                break
            elif type(value) == str:
                if 'None'.lower() in value.lower() or 'N/A'.lower() in value.lower():
                    self.logger.error('Leave Ticket ID(s) empty, if no ticket was created...')
                    self.validation_successful = False
                    validation_successful = False
                    break
            else:
                self.logger.warn('Ticket ID(s) {} is {}...'.format(value, type(value)))
        if not validation_successful:
            self.logger.error('Try changing the relevant column format to "Plain Text" and try again...')
        wb_obj.close()
        return validation_successful

    
    def validate_alert_ids(self, input_file, column_name):
        validation_successful = True
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for value in self.get_all_values_from_column(active_sheet, column_name):
            if type(value) == int:
                self.logger.debug('Alert ID(s) {} is in correct format "str"...'.format(value))
            elif type(value) == float:
                self.logger.error('Alert ID(s) {} is not in correct format "str"...'.format(value))
                self.validation_successful = False
                validation_successful = False
                break
            elif type(value) == str:
                self.logger.debug('Alert ID(s) {} is in correct format "str"...'.format(value))
                if '\n' in value or '\r' in value:
                    self.logger.error('Alert ID(s) "{}" should not contain "\\n"...'.format(value))
                    self.validation_successful = False
                    validation_successful = False
                    break
            else:
                self.logger.warn('Alert ID(s) {} is {}...'.format(value, type(value)))
        if not validation_successful:
            self.logger.error('Try changing the relevant column format to "Plain Text" and try again...')
        wb_obj.close()
        return validation_successful

    
    def validate_analysis_date(self, input_file, column_name):
        validation_successful = True
        rows_list = []
        wb_obj = openpyxl.load_workbook(input_file)
        active_sheet = wb_obj['Analysis_Summary']
        for idx, value in enumerate(self.get_all_values_from_column(active_sheet, column_name)):
            value = datetime.strftime(value, self.analysis_date_format)
            if self.validate_date_v2(value, self.analysis_date_format):
                self.logger.info('Analysis date {} is in correct format {}...'.format(value, self.analysis_date_format))
                if value == self.get_date_today_in_str():
                    self.logger.info(f"rows for required summary day = {idx} for value {value} and date today {self.get_date_today_in_str()}")
                    rows_list.append(idx)
            else:
                self.logger.error('Analysis Date time {} is not in correct format {}...'.format(value, self.analysis_date_format))
                self.validation_successful = False
                validation_successful = False
                break
        rows_list.sort()
        self.min_row = rows_list[0]
        self.max_row = rows_list[-1]+2
        self.logger.info(f"rows_list = {rows_list}\nmin_row = {self.min_row}\nmax_row = {self.max_row}\nmax_rows in sheet = {active_sheet.max_row}")
        # exit()
        
        wb_obj.close()
        # exit(1)
        return validation_successful


    def get_unique_values_for_column(self, active_sheet, column_name, do_client_filter=False):
        unique_ds = set()
        for row in active_sheet.iter_rows(2, values_only=True):
            for idx, cell in enumerate(row):
                if idx == self.header_dict[column_name]:
                    if not (do_client_filter and self.client in cell.lower()):
                        continue
                    unique_ds.add(cell)
        unique_ds = list(unique_ds)
        self.logger.debug('print unique datasources:')
        pprint(unique_ds)
        return unique_ds

        
    def get_investigated_alerts_count(self, active_sheet, min_row=-1, max_row=-1):
        count = 0

        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for row in active_sheet.iter_rows(min_row, max_row, values_only=True):
            if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and self.summary_type == 'merged':
                count += int(row[self.header_dict['Alerts Count']])
            else:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and row[self.header_dict['Shift']].lower() == self.summary_type:
                    count += int(row[self.header_dict['Alerts Count']])
        self.logger.info('Investigated alerts count: {}'.format( count))
        return count

        
    def get_investigated_alerts_count_by_datasource(self, active_sheet, datasource, min_row=-1, max_row=-1):
        count = 0
        
        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for row in active_sheet.iter_rows(min_row, max_row, values_only=True):
            if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and self.summary_type == 'merged':
                if row[self.header_dict['Datasource']] == datasource:
                    count += int(row[self.header_dict['Alerts Count']])
            else:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and row[self.header_dict['Shift']].lower() == self.summary_type and row[self.header_dict['Datasource']] == datasource:
                    count += int(row[self.header_dict['Alerts Count']])
        self.logger.info('Investigated alerts count for DS {}: {}'.format(datasource, count))
        return int(count)

    
    def get_count_by_analysis_status_per_ds(self, active_sheet, datasource, analysis_status='TP', min_row=-1, max_row=-1):
        count = 0
        
        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for row in active_sheet.iter_rows(min_row, max_row, values_only=True):
            if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and self.summary_type == 'merged':
                if row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Analysis Status']] == analysis_status:
                    count += 1
            else:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and row[self.header_dict['Shift']].lower() == self.summary_type and row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Analysis Status']] == analysis_status:
                    count += 1
        self.logger.info('TP count for DS {}: {}'.format(datasource, count))
        return count

    
    def tkt_cu_count(self, active_sheet, datasource, min_row=-1, max_row=-1):
        count = 0

        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for row in active_sheet.iter_rows(min_row, max_row, values_only=True):
            if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and self.summary_type == 'merged':
                # self.logger.debug('Early -- Row number {} for ticket ID {} type ({})...'.format(count, row[self.header_dict['Ticket ID']], type(row[self.header_dict['Ticket ID']])))

                if row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Ticket ID']] and 'None' not in str(row[self.header_dict['Ticket ID']]):
                    count += 1
                    
                    # self.logger.debug('Post -- Row number {} for ticket ID {}...'.format(count, row[self.header_dict['Ticket ID']]))
            else:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and row[self.header_dict['Shift']].lower() == self.summary_type and row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Ticket ID']] and 'None' not in str(row[self.header_dict['Ticket ID']]):
                    count += 1
        self.logger.info('Tickets created/updated count for DS {}: {}'.format(datasource, count))
        return count


    def pending_alerts_count(self, active_sheet, datasource, min_row=-1, max_row=-1):
        count = 0
        
        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for row in active_sheet.iter_rows(min_row, max_row, values_only=True):
            if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and self.summary_type == 'merged':
                if row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Alert Status']] == 'Pending':
                    count += 1
            else:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and row[self.header_dict['Shift']].lower() == self.summary_type and row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Alert Status']] == 'Pending':
                    count += 1
        self.logger.info('Pending alerts count for DS {}: {}'.format(datasource, count))
        return count


    def pending_alerts_count_by_priority(self, active_sheet, datasource, priority, min_row=-1, max_row=-1):
        count = 0
        
        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for row in active_sheet.iter_rows(min_row, max_row, values_only=True):
            if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and self.summary_type == 'merged':
                if row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Alert Status']] == 'Pending' and row[self.header_dict['Alert Priority']] == priority:
                    count += 1
            else:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and row[self.header_dict['Shift']].lower() == self.summary_type and row[self.header_dict['Datasource']] == datasource and row[self.header_dict['Alert Status']] == 'Pending' and row[self.header_dict['Alert Priority']] == priority:
                    count += 1
        self.logger.info('Pending {} alerts count for DS {}: {}'.format(priority, datasource, count))
        return count


    def get_header_mapped_alert_details_per_ds(self, active_sheet, datasource, min_row=-1, max_row=-1):
        header_mapped_alert_details = []
        
        # setup min and max rows by default and when as required
        if self.min_row == -1: min_row = 2
        else: min_row = self.min_row
        if self.max_row == -1: max_row = active_sheet.max_row
        else: max_row = self.max_row

        for index, row in enumerate(active_sheet.iter_rows(min_row, max_row, values_only=True)):
            if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and self.summary_type == 'merged':
                if row[self.header_dict['Datasource']] == datasource :
                    temp_dict = {}
                    for idx_row, item in enumerate(row):
                        temp_dict[self.header_list[idx_row]] = item
                    header_mapped_alert_details.append(temp_dict)
            else:
                if self.date_today == datetime.strftime(row[self.header_dict['Analysis Date']], self.analysis_date_format) and self.client in row[self.header_dict['Datasource']].lower() and row[self.header_dict['Shift']].lower() == self.summary_type and row[self.header_dict['Datasource']] == datasource:
                    temp_dict = {}
                    for idx_row, item in enumerate(row):
                        temp_dict[self.header_list[idx_row]] = item
                    header_mapped_alert_details.append(temp_dict)
        self.logger.info('Alert details for DS {} added & mapped to header'.format(datasource))
        pprint(header_mapped_alert_details)
        return header_mapped_alert_details
        
    
    def summary_details(self, sheet='Analysis_Summary'):
        wb_obj = openpyxl.load_workbook(self.input_file)
        active_sheet = wb_obj['Analysis_Summary']
        
        logging.debug(active_sheet.max_row)
        logging.debug(active_sheet.max_column)
        self.set_header(active_sheet)
        self.append_to_output_file('*Total Investigated Alerts: {}*\n\n\n'.format(self.get_investigated_alerts_count(active_sheet)))
        unique_ds = self.get_unique_values_for_column(active_sheet, 'Datasource', do_client_filter=True)
        for ds in unique_ds:
            self.append_to_output_file('\n*{}*\n\n'.format(ds.split(' - ', maxsplit=1)[-1]))
            ia_count = self.get_investigated_alerts_count_by_datasource(active_sheet, ds)
            self.append_to_output_file('*Alerts Investigated: {}*\n\n'.format(ia_count))
            tp_count = self.get_count_by_analysis_status_per_ds(active_sheet, ds)
            self.append_to_output_file('`--TP: {}`\n\n'.format(tp_count))
            tkt_count = self.tkt_cu_count(active_sheet, ds)
            self.append_to_output_file('`--Tickets Created/Updated: {}`\n\n'.format(tkt_count))
            pending_count = self.pending_alerts_count(active_sheet, ds)
            self.append_to_output_file('`--Total Pending: {} - C: {} | H: {} | M: {} | L: {} | I: {}`\n\n'.format(
                pending_count,
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Critical'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'High'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Medium'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Low'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Informational')))
            alert_details = self.get_header_mapped_alert_details_per_ds(active_sheet, ds)
            alert_detail_idx = 0
            for idx, deet in enumerate(alert_details):
                # skip FPs from summary
                if deet['Analysis Status'] == 'FP': continue
                #######################
                alert_detail_idx += 1
                self.append_to_output_file('```\n{}- {}\nAlert ID(s): {}\nPriority: {}\nAlert Status: {}\nAnalysis Status: {}\nTicket ID: {}\nAlerts Count: {}\nFirst Activity: {}\nLast Activity: {}\n\nDetails:\n{}\n\nAction Items & Recommendations:\n{}\n```\n\n'.format(
                    alert_detail_idx,
                    self.sanitize_string(deet['Alert Title']),
                    self.sanitize_string(deet['Alert ID(s)']),
                    self.sanitize_string(deet['Alert Priority']),
                    self.sanitize_string(deet['Alert Status']),
                    self.sanitize_string(deet['Analysis Status']),
                    self.sanitize_string(deet['Ticket ID']),
                    self.sanitize_string(deet['Alerts Count']),
                    self.sanitize_string(deet['Time of first event']),
                    self.sanitize_string(deet['Time of last event']),
                    self.sanitize_string(deet['Alert Details']),
                    self.sanitize_string(deet['Action Items'])
                ))
        wb_obj.close()


    def create_summary(self):
        self.run_validate()
        if self.validation_successful:
            self.append_to_output_file('*SOC Analysis Summary - {} --- `{}`*\n\n'.format(self.date_today, self.summary_type.capitalize()))
            if self.client == 'moonfare':
                analysis_summary_moonfare(self.date_today, self.client, self.summary_type, self.input_file, self.output_file, self.logger, active_collab=self.active_collab).summary_details()
            elif self.client == 'careem':
                analysis_summary_careem(self.date_today, self.client, self.summary_type, self.input_file, self.output_file, self.logger, active_collab=self.active_collab).summary_details()
            elif self.client == 'yap' or self.client == 'yap - uae':
                analysis_summary_yap(self.date_today, self.client, self.summary_type, self.input_file, self.output_file, self.logger, active_collab=self.active_collab).summary_details()
            else: self.summary_details()
            self.logger.info('{} {} summary for {} added to output file {}...'.format(self.date_today, self.summary_type, self.client, self.output_file))
        else: return

    
class analysis_summary_moonfare(general_analysis_summary):


    # def __init__(self, date_today, client, summary_type, input_file, output_file, logger, active_collab=None):
    #     super().__init__(date_today, client, summary_type, input_file, output_file, logger, active_collab=active_collab)


    def summary_details(self, sheet='Analysis_Summary'):
        wb_obj = openpyxl.load_workbook(self.input_file)
        active_sheet = wb_obj['Analysis_Summary']
        
        logging.debug(active_sheet.max_row)
        logging.debug(active_sheet.max_column)
        self.set_header(active_sheet)
        self.append_to_output_file('*Total Investigated Alerts: {}*\n\n\n'.format(self.get_investigated_alerts_count(active_sheet)))
        unique_ds = self.get_unique_values_for_column(active_sheet, 'Datasource', do_client_filter=True)
        for ds in unique_ds:
            self.append_to_output_file('\n*{}*\n\n'.format(ds.split(' - ', maxsplit=1)[-1]))
            ia_count = self.get_investigated_alerts_count_by_datasource(active_sheet, ds)
            self.append_to_output_file('*Alerts Investigated: {}*\n\n'.format(ia_count))
            tp_count = self.get_count_by_analysis_status_per_ds(active_sheet, ds)
            self.append_to_output_file('`--TP: {}`\n\n'.format(tp_count))
            tkt_count = self.tkt_cu_count(active_sheet, ds)
            self.append_to_output_file('`--Tickets Created/Updated: {}`\n\n'.format(tkt_count))
            pending_count = self.pending_alerts_count(active_sheet, ds)
            self.append_to_output_file('`--Total Pending: {} - C: {} | H: {} | M: {} | L: {} | I: {}`\n\n'.format(
                pending_count,
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Critical'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'High'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Medium'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Low'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Informational')))
            alert_details = self.get_header_mapped_alert_details_per_ds(active_sheet, ds)
            alert_detail_idx = 0
            for idx, deet in enumerate(alert_details):
                # skip FPs from summary
                if deet['Analysis Status'] == 'FP': continue
                #######################
                alert_detail_idx += 1
                self.append_to_output_file('```\n{}- {}\nAlert ID(s): {}\nPriority: {}\nAlert Status: {}\nAnalysis Status: {}\nTicket ID: {}\n\nDetails: {}\n\nAction Items & Recommendations:\n{}\n```\n\n'.format(
                    alert_detail_idx,
                    self.sanitize_string(deet['Alert Title']),
                    self.sanitize_string(deet['Alert ID(s)']),
                    self.sanitize_string(deet['Alert Priority']),
                    self.sanitize_string(deet['Alert Status']),
                    self.sanitize_string(deet['Analysis Status']),
                    self.sanitize_string(deet['Ticket ID']),
                    self.sanitize_string(deet['Alert Details']),
                    self.sanitize_string(deet['Action Items'])
                ))
        wb_obj.close()


class analysis_summary_careem(general_analysis_summary):


    # def __init__(self, date_today, client, summary_type, input_file, output_file, logger, active_collab=None):
    #     super().__init__(date_today, client, summary_type, input_file, output_file, logger, active_collab=active_collab)


    def summary_details(self, sheet='Analysis_Summary'):
        wb_obj = openpyxl.load_workbook(self.input_file)
        active_sheet = wb_obj['Analysis_Summary']
        
        logging.debug(active_sheet.max_row)
        logging.debug(active_sheet.max_column)
        self.set_header(active_sheet)
        self.append_to_output_file('*Total Investigated Alerts: {}*\n\n\n'.format(self.get_investigated_alerts_count(active_sheet)))
        unique_ds = self.get_unique_values_for_column(active_sheet, 'Datasource', do_client_filter=True)
        for ds in unique_ds:
            self.append_to_output_file('\n*{}*\n\n'.format(ds.split(' - ', maxsplit=1)[-1]))
            ia_count = self.get_investigated_alerts_count_by_datasource(active_sheet, ds)
            self.append_to_output_file('*Alerts Investigated: {}*\n\n'.format(ia_count))
            tp_count = self.get_count_by_analysis_status_per_ds(active_sheet, ds)
            self.append_to_output_file('`--TP: {}`\n\n'.format(tp_count))
            tkt_count = self.tkt_cu_count(active_sheet, ds)
            self.append_to_output_file('`--Tickets Created/Updated: {}`\n\n'.format(tkt_count))
            pending_count = self.pending_alerts_count(active_sheet, ds)
            self.append_to_output_file('`--Total Pending: {} - C: {} | H: {} | M: {} | L: {} | I: {}`\n\n'.format(
                pending_count,
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Critical'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'High'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Medium'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Low'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Informational')))
            alert_details = self.get_header_mapped_alert_details_per_ds(active_sheet, ds)
            alert_detail_idx = 0
            for idx, deet in enumerate(alert_details):
                # skip FPs from summary
                if deet['Analysis Status'] == 'FP': continue
                #######################
                alert_detail_idx += 1
                # skip details, if no action items
                if deet.get('Action Items') is None or deet.get('Action Items') == 'None' or deet.get('Action Items') == '' or deet.get('Action Items') == ' ':
                    continue
                #######################
                self.append_to_output_file('```\n{}- {}\nAlert ID(s): {}\nPriority: {}\nAlert Status: {}\nAnalysis Status: {}\nTicket ID: {}\n\nDetails: {}\n\nAction Items & Recommendations:\n{}\n```\n\n'.format(
                    alert_detail_idx,
                    self.sanitize_string(deet['Alert Title']),
                    self.sanitize_string(deet['Alert ID(s)']),
                    self.sanitize_string(deet['Alert Priority']),
                    self.sanitize_string(deet['Alert Status']),
                    self.sanitize_string(deet['Analysis Status']),
                    self.sanitize_string(deet['Ticket ID']),
                    self.sanitize_string(deet['Alert Details']),
                    self.sanitize_string(deet['Action Items'])
                ))
        wb_obj.close()


class analysis_summary_yap(general_analysis_summary):


    # def __init__(self, date_today, client, summary_type, input_file, output_file, logger, active_collab=None):
    #     super().__init__(date_today, client, summary_type, input_file, output_file, logger, active_collab=active_collab)


    def summary_details(self, sheet='Analysis_Summary'):
        wb_obj = openpyxl.load_workbook(self.input_file)
        active_sheet = wb_obj['Analysis_Summary']
        
        logging.debug(active_sheet.max_row)
        logging.debug(active_sheet.max_column)
        self.set_header(active_sheet)
        self.append_to_output_file('*Total Investigated Alerts: {}*\n\n\n'.format(self.get_investigated_alerts_count(active_sheet)))
        unique_ds = self.get_unique_values_for_column(active_sheet, 'Datasource', do_client_filter=True)
        for ds in unique_ds:
            self.append_to_output_file('\n*{}*\n\n'.format(ds.split(' - ', maxsplit=1)[-1]))
            ia_count = self.get_investigated_alerts_count_by_datasource(active_sheet, ds)
            self.append_to_output_file('*Alerts Investigated: {}*\n\n'.format(ia_count))
            tp_count = self.get_count_by_analysis_status_per_ds(active_sheet, ds)
            self.append_to_output_file('`--TP: {}`\n\n'.format(tp_count))
            tkt_count = self.tkt_cu_count(active_sheet, ds)
            self.append_to_output_file('`--Tickets Created/Updated: {}`\n\n'.format(tkt_count))
            pending_count = self.pending_alerts_count(active_sheet, ds)
            self.append_to_output_file('`--Total Pending: {} - C: {} | H: {} | M: {} | L: {} | I: {}`\n\n'.format(
                pending_count,
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Critical'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'High'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Medium'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Low'),
                self.pending_alerts_count_by_priority(active_sheet, ds, 'Informational')))
            alert_details = self.get_header_mapped_alert_details_per_ds(active_sheet, ds)
            alert_detail_idx = 0
            for idx, deet in enumerate(alert_details):
                # skip FPs from summary
                # if deet['Analysis Status'] == 'FP': continue
                #######################
                alert_detail_idx += 1
                # skip details, if no action items
                # if deet.get('Action Items') is None or deet.get('Action Items') == 'None' or deet.get('Action Items') == '' or deet.get('Action Items') == ' ':
                #     continue
                #######################
                self.append_to_output_file('```\n{}- {}\nAlert ID(s): {}\nPriority: {}\nAlert Status: {}\nAnalysis Status: {}\nTicket ID: {}\n\nDetails: {}\n\nAction Items & Recommendations:\n{}\n```\n\n'.format(
                    alert_detail_idx,
                    self.sanitize_string(deet['Alert Title']),
                    self.sanitize_string(deet['Alert ID(s)']),
                    self.sanitize_string(deet['Alert Priority']),
                    self.sanitize_string(deet['Alert Status']),
                    self.sanitize_string(deet['Analysis Status']),
                    self.sanitize_string(deet['Ticket ID']),
                    self.sanitize_string(deet['Alert Details']),
                    self.sanitize_string(deet['Action Items'])
                ))
        wb_obj.close()