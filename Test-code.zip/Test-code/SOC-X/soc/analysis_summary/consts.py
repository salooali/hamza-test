consts = {
    'client_allowed_values': [
        'careem',
        'moonfare',
        'smiota',
        'veeone',
        'lums',
        'yap',
        'yap - uae',
        'fmfb',
        'bipl',
        'sptn',
        'ebryx',
        'fe'
    ],
    'summary_type_allowed_values' : [
        'merged',
        'morning',
        'evening',
        'night'
    ],
    'analysis_status_allowed_values': [
        'TP',
        'FP',
        'FN',
        'TN',
        'Undecided',
        'TP without Actionable',
        'Informational'
    ],
    'alert_status_allowed_values': [
        'Pending',
        'In-Progress',
        'Done without actions performed',
        'Done'
    ],
    'alert_priority_allowed_values': [
        'Critical',
        'High',
        'Medium',
        'Low',
        'Informational'
    ]
}
