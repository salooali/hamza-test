from . import analysis_summary
from helpers import active_collab


class asc_main:


    summary_type = None
    date_today = None
    client = None
    input_file = None
    output_file = None
    active_collab_config = None
    logger = None


    def __init__(self, logger, summary_type, date_today, client, input_file, active_collab_config, output_file):
        self.logger = logger
        self.summary_type = summary_type
        self.date_today = date_today
        self.client = client
        self.input_file = input_file
        self.output_file = output_file
        self.active_collab_config = active_collab_config


    def main(self):
        if self.summary_type:
            self.logger.info('Summary type value passed...')
            if self.date_today:
                self.logger.info('Date passed...')
                if self.client:
                    self.logger.info('Client passed...')
                    if self.input_file:
                        self.logger.info('Input file passed...')
                        anasum = analysis_summary.general_analysis_summary(self.date_today, self.client, self.summary_type, self.input_file, self.output_file, self.logger)
                        anasum.create_summary()
                        if self.active_collab_config:
                            ac_mod = active_collab.active_collab(self.active_collab_config, self.logger)
                            ac_mod.log_time_for_analysis(
                                anasum.get_time_to_log(ac_mod.config.get('credentials').get('analyst')),
                                self.client,
                                anasum.get_date_today_in_str()  
                            )
                    else:
                        self.logger.error('Input file value not passed...')
                else:
                    self.logger.error('Client value not passed...')
            else:
                self.logger.error('Date today value not passed...')
        else:
            self.logger.error('Summary type value not provided...')