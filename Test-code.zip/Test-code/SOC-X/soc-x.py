import os
import argparse
from datetime import date
from helpers import utils
from soc.analysis_summary import asc_main, consts
from soc.response.ip_block import ip_block, consts as ib_consts
from soc.query.lb_waf_attachment import aws_lb_waf_attachment
from soc.monthly_report_siem import reporter, config, reporter_veeone


# global vars
#############
logger = utils.setup_logger()
args = None
constants = {
    'allowed_work_types': [
        "analysis_summary",
        "response_ip_block",
        "query_lb_waf_attachment",
        "monthly_report"
    ]
}
#############


def empty_output_file(output='.output.txt'):
    with open(output, "w") as outfile: pass
    logger.info('Output file {} has been created and emptied...'.format(output))
    return output


def setup_args():
    parser = argparse.ArgumentParser(os.path.basename(__file__), usage='''

    First time setting up soc-x:
        git clone soc-x_github_link
        cd SOC-X
        pipenv install
        exit
        pipenv run soc-x.py -h

    SOC - Sample Usages:
        Compile analysis summary:
            Compile 25th Nov merged summary for sptn and log your analysis time on Active Collab
                git pull origin main; pipenv run python soc-x.py --team soc --work_type analysis_summary --summary_type merged --client sptn --input_file Downloads\SPTN-Analysis_Summary-23112021.xlsx -dt 2021-11-25 --output_file .output.txt.md -acc configs\.active-collab.json
            Compile for 14th Nov 2021 morning shift for careem:
                git pull origin main; pipenv run python soc-x.py --team soc --work_type analysis_summary --summary_type morning --client careem --input_file .\samples\inputs\my-analysis_summary\Client-Analysis_Summary-15112021.xlsx -dt 2021-11-14 --output_file .output.txt.md
            Compile merged for 14th Nov 2021 for careem:
                git pull origin main; pipenv run python soc-x.py --team soc --work_type analysis_summary --summary_type merged --client careem --input_file .\samples\inputs\\analysis_summary\Client-Analysis_Summary-15112021.xlsx -dt 2021-11-14 --output_file .output.txt.md

        Block a list of IPs on AWS WAF Regional for Careem
            git pull origin main; pipenv run python .\soc-x.py --team soc -wt response_ip_block -ro aws -i .\samples\inputs\\response\iplist.txt -wiba INSERT -apn careem-prod-temp -ar eu-west-1 -waft waf-regional -isi 33d2aea6-db91-488f-95ed-4b0f72e4f894

        
        Unblock a list of IPs on AWS WAF Regional for Careem
            git pull origin main; pipenv run python .\soc-x.py --team soc -wt response_ip_block -ro aws -i .\samples\inputs\\response\iplist.txt -wiba DELETE -apn careem-prod-temp -ar eu-west-1 -waft waf-regional -isi 33d2aea6-db91-488f-95ed-4b0f72e4f894


        Query for AWS WAF Loadbalancer attachment status using loadbalancer ARN
            pipenv run python .\soc-x.py --team soc -wt query_lb_waf_attachment -apn careem-prod-temp -lb_id pipenv run python .\soc-x.py --team soc -wt query_lb_waf_attachment -apn careem-prod-temp -lb_arn arn:aws:elasticloadbalancing:eu-west-1:617171697645:loadbalancer/app/awseb-AWSEB-11DSBESZTDV5E/b2ba4c65b2eb6bdb -ar eu-west-1 -ar eu-west-1

        Query for AWS WAF Loadbalancer attachment status using loadbalancer ID
            pipenv run python .\soc-x.py --team soc -wt query_lb_waf_attachment -apn careem-prod-temp -lb_arn awseb-AWSEB-11DSBESZTDV5E
    ''')
    parser.add_argument('-v', '--verbosity', metavar='<verbosity>', type=str, help='Verbosity level of the output. Eg: DEBUG|INFO|WARN|ERROR', default='DEBUG')
    logger.info('Arguments parsed successfully...')
    parser.add_argument('-c', '--config', metavar='<config_file_path>', type=str, default='config/.config.json', help='Config file path. Eg: /path/to/config.json')
    parser.add_argument('-acc', '--active_collab_config', metavar='<active_collab_config_file_path>', type=str, default='configs/.active-collab.json', help='Config file path. Eg: /path/to/config.json')
    parser.add_argument('-o', '--output_file', metavar='<output_file_path>', type=str, default='.output.txt', help='Output file path. Eg: /path/to/.output.txt')
    parser.add_argument('-t', '--team', metavar='<team>', type=str, default='soc', help='Team name. Eg: soc, dfir, shared')
    parser.add_argument('-wt', '--work_type', metavar='<work_type>', type=str, help='Work type. Eg: {}...'.format(constants.get('allowed_work_types')))
    parser.add_argument('-st', '--summary_type', metavar='<summary_type>', type=str, help='Summary type. Eg: {}...'.format(consts.consts.get('summary_type_allowed_values')))
    parser.add_argument('-dt', '--date_today', metavar='<date_today>', type=str, default=str(date.today()), help='Date Today. Eg: YYYY-MM-DD')
    parser.add_argument('-sd', '--start_date', metavar='<start_date>', type=str, default=str(date.today()), help='UNUSED -- Start Date. Eg: YYYY-MM-DD')
    parser.add_argument('-ed', '--end_date', metavar='<end_date>', type=str, default=str(date.today()), help='UNUSED -- End date. Eg: YYYY-MM-DD')
    parser.add_argument('-cl', '--client', metavar='<client>', type=str, help='Client name. Eg: {}...'.format(consts.consts.get('client_allowed_values')))
    parser.add_argument('-i', '--input_file', metavar='<input_file>', type=str, help='Input file path. Eg: /path/to/summary.xlsx')
    logger.info('Arguments parsed successfully...')
    parser.add_argument('-wiba', '--waf_ip_block_action', metavar='<waf_ip_block_action>', type=str, default="INSERT", help='WAF action to be taken on the given IP list. Are these IPs to be inserted or deleted from a given IP set. Eg: INSERT|DELETE')
    parser.add_argument('-apn', '--aws_profile_name', metavar='<aws_profile_name>', type=str, default="default", help='AWS profile name')
    parser.add_argument('-ar', '--aws_region', metavar='<aws_region>', type=str, default="eu-west-1", help='AWS region. Eg: eu-west-1')
    logger.info('Arguments parsed successfully...')
    parser.add_argument('-waft', '--waf_type', metavar='<waf_type>', type=str, default="waf-regional", help='WAF type. Eg: for AWS, waf type could be any of {}'.format(ib_consts.consts.get('waf_type_allowed_values')))
    parser.add_argument('-isi', '--ipset_id', metavar='<ipset_id>', type=str, default="", help='IP set unique ID. Eg: for AWS, IP set ID would be a GUID value')
    parser.add_argument('-ro', '--respond_on', metavar='<respond_on>', type=str, default="aws", help='Respond on what platform. Eg: aws etc.')
    parser.add_argument('-lb_arn', '--loadbalancer_arn', metavar='<loadbalancer_arn>', type=str, default=None, help='Loadbalancer ARN. Eg: arn:aws:elasticloadbalancing:us-east-2:123456789012:elb/app/73e2d6bc24d8a067 etc.')
    parser.add_argument('-lb_id', '--loadbalancer_id', metavar='<loadbalancer_id>', type=str, default=None, help='Loadbalancer ID. Eg: loadbalancer-id or app/load-balancer-id/id etc.')
    parser.add_argument('-rm', '--report_month', metavar='<report_month>', type=str, help='Report Month. Eg: MM')
    parser.add_argument('-ry', '--report_year', metavar='<report_year>', type=str, help='Report Year. Eg: YYYY')
    logger.info('Arguments parsed successfully...')
    return parser.parse_args()


def main():
    global args, logger
    args = setup_args()
    logger.setLevel(args.verbosity)
    empty_output_file(args.output_file)

    # what team work to do
    if args.team == 'soc':
        # work types that can be done within soc based on passed arguments
        if args.work_type in constants.get('allowed_work_types'):
            if args.work_type == 'analysis_summary':
                # work on analysis summary
                # call analysis summary module
                asc_main.asc_main(logger, args.summary_type, args.date_today, args.client, args.input_file, args.active_collab_config, args.output_file).main()
            elif args.work_type == 'query_lb_waf_attachment':
                # respond type work done by analysts for IP blocking
                logger.info('Querying AWS loadbalancer WAF attachment')
                aws_lb_waf_attachment.aws_lb_waf_attachment(logger, args.aws_profile_name, aws_region=args.aws_region, 
                loadbalancer_id=args.loadbalancer_id, loadbalancer_arn=args.loadbalancer_arn).waf_attachment_status()
            elif args.work_type == 'response_ip_block':
                # respond type work done by analysts for IP blocking
                logger.debug('responding to IP block')
                ip_block.ip_block(logger, args.input_file, args.waf_ip_block_action, args.respond_on).main(args.aws_profile_name, args.aws_region, args.waf_type, args.ipset_id)
            elif args.work_type == 'monthly_report':
                # respond type work done by analysts for IP blocking
                logger.info('Generating the monthly report')
                if args.client == "veeone":
                    report = reporter_veeone.monthly_report_parent(args.report_year, args.report_month, args.client, args.input_file, logger)
                else:
                    report = reporter.monthly_report_parent(args.report_year, args.report_month, args.client, args.input_file, logger)
                report.create_report()
        else:
            logger.error('No valid work type')
    else:
        logger.error('No valid team defined...')



if __name__ == '__main__':
    main()
    # try to make a sound at the end of execution
    print('\a')